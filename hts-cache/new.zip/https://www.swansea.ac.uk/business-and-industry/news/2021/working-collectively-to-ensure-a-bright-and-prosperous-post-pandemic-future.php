<!DOCTYPE html>
<html class="no-js" lang="en-GB" prefix="og: http://ogp.me/ns#">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-2764516-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-2764516-1');
  gtag('config', 'UA-2764516-41');
</script>
            <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/fonts/futura/hinted-FuturaPTBold-Reg.woff2?ik-sdk-version=php-2.0.0" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/fonts/futura/hinted-FuturaPTBook-Reg.woff2?ik-sdk-version=php-2.0.0" as="font" type="font/woff2" crossorigin>

    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/js/www-bundle.min.js?v=b348f1a3104466ceba9ead35abeb8974&ik-sdk-version=php-2.0.0" as="script">

    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/css/general.min.css?v=cadd65eee68e59e01d07512b07c275b2&ik-sdk-version=php-2.0.0" as="style">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta property="su:section-id" content="44251" />
    
<meta name="description" content="Read more about Swansea University's business-focused news from 2020." />





    <meta name="description" content="Over the last two years, organisations across every sector have grappled with the dual impacts of Brexit and a global pandemic. Here, Vice-Chancellor Professor Paul Boyle considers Swansea University’s role in the recovery of our region and nation, and the opportunities for greater collaboration between universities and industry partners in the months and years to come.">
<meta property="su:page-type" content="News Item">
<meta property="og:title" content="Working collectively to ensure a bright and prosperous post-pandemic future">
<meta property="og:type" content="article">
<meta property="og:url" content="https://www.swansea.ac.uk/business-and-industry/news/2021/working-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php">
<meta property="og:description" content="Over the last two years, organisations across every sector have grappled with the dual impacts of Brexit and a global pandemic. Here, Vice-Chancellor Professor Paul Boyle considers Swansea University’s role in the recovery of our region and nation, and the opportunities for greater collaboration between universities and industry partners in the months and years to come.">
<meta property="og:image" content="https://www.swansea.ac.uk/business-and-industry/news/2021/VC-article.jpg">
<meta property="og:image:alt" content="Professor Paul Boyle, Swansea University Vice Chancellor ">
<meta property="og:locale" content="en_GB">
<meta property="og:site_name" content="Swansea University">
    <title>Working collectively to ensure a bright and prosperous post-pandemic future - Swansea University</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/icons/apple-touch-icon.png?ik-sdk-version=php-2.0.0">
        <link rel="icon" type="image/png" sizes="32x32" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon-32x32.png?ik-sdk-version=php-2.0.0">
    <link rel="icon" type="image/png" sizes="16x16" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon-16x16.png?ik-sdk-version=php-2.0.0">
    <link rel="manifest" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/site.webmanifest?ik-sdk-version=php-2.0.0">
    <link rel="mask-icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/safari-pinned-tab.svg?ik-sdk-version=php-2.0.0" color="#5bbad5">
    <link rel="shortcut icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon.ico?ik-sdk-version=php-2.0.0">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/browserconfig.xml?ik-sdk-version=php-2.0.0">
    <meta name="theme-color" content="#ffffff">

        <link rel="stylesheet" href="https://ik.imagekit.io/s1sp3stox/_web/css/general.min.css?v=cadd65eee68e59e01d07512b07c275b2&ik-sdk-version=php-2.0.0" type="text/css" media="all" />

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        function isAtLeastPartiallyVisible(el) {
            const rect = el.getBoundingClientRect();
            return rect.top < window.innerHeight && rect.bottom >= 0;
        }

        document.querySelectorAll('img').forEach(function(img) {
            if (isAtLeastPartiallyVisible(img)) {
                img.removeAttribute('loading');
            } else {
                img.setAttribute('loading', 'lazy');
            }
        });
    }, false);
</script>

    <script src="https://kit.fontawesome.com/026410dcd9.js" crossorigin="anonymous"></script>

        <link rel="canonical" href="https://www.swansea.ac.uk/business-and-industry/news/2021/working-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" />

    <script>
      (function(d) {
        var config = {
          kitId: 'lnz6iij',
          scriptTimeout: 3000,
          async: true
        },
        h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
      })(document);
    </script>

    <script>
        var SU = {
            injectedScripts: []
        };
    </script>



<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5MZHZM');</script></head>

<body>

<noscript><iframe title="Google Tag Manager" src="//www.googletagmanager.com/ns.html?id=GTM-5MZHZM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<script data-cookieconsent="ignore">
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag("consent", "default", {
        ad_storage: "denied",
        analytics_storage: "denied",
        wait_for_update: 500
    });
    gtag("set", "ads_data_redaction", true);
</script>

    <header id="banner">
        <div class="container">
            <a class="skip-to-main" href="#main">Skip to main content</a>

    
<a href="/" class="logo logo-www">
    <picture>
        <source type="image/svg+xml" srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.svg?ik-sdk-version=php-2.0.0" />
        <img
            src="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0"
            srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0, https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en@2x.png?ik-sdk-version=php-2.0.0 2x"
            alt="Swansea University"
            width="185"
            height="116"
        />
    </picture>
</a>

    <form method="GET" role="search" aria-label="site search" action="/search/">
        <label for="keywords">Search:</label>
        <input type="text" id="keywords" name="q" placeholder="Search Swansea University" />
        <input name="c" value="www-en-meta" type="hidden" />
        <button id="search-button" aria-label="site search button" type="submit" tabindex="0">Search</button>
    </form>

    <script>
    SU.injectedScripts.push(function ($) {
        $('#keywords').autocompletion({
            datasets: {
                organic: {
                collection: 'www-en-meta',
                profile   : '_default',
                program   : 'https://swansea.funnelback.co.uk/s/suggest.json',
            }
        },
        length: 3
      });
    });
</script>
        
    <ul class="utility-links">

    <li>
        <a href="/jobs-at-swansea/" title="Jobs at Swansea University">Jobs</a>
    </li>

    <li>
        <a class="utility-links-recite-me-link" href="#" onclick="return false;" title="Accessibility Tools">Accessibility Tools</a>
    </li>

    <li>
        <a href="https://myuni.swansea.ac.uk/">Current Students</a>
    </li>

    <li>
        <a href="https://staff.swansea.ac.uk/">Staff</a>
    </li>

    <li>
        <a href="http://www.swanseauniversity.com.cn/" aria-label="A link to information in Chinese about Swansea University">中文</a>
    </li>

    <li>
        <a href="/cy/busnes/newyddion/2021/cydweithio-i-sicrhau-dyfodol-disglair-a-ffyniannus-ar-ol-y-pandemig.php" lang="cy-GB">Cymraeg</a>
    </li>

</ul>

        </div>
    </header>


    <nav class="navbar navbar-expand-lg primary-nav  yamm ">
        <div class="container">
            <button class="navbar-toggler" data-toggle="collapse" data-target="#primary-nav-content">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30" focusable="false"><title>Menu</title><path stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-miterlimit="10" d="M4 7h22M4 15h22M4 23h22"></path></svg>
            </button>
    
<a href="/" class="logo logo-www">
    <picture>
        <source type="image/svg+xml" srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.svg?ik-sdk-version=php-2.0.0" />
        <img
            src="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0"
            srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0, https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en@2x.png?ik-sdk-version=php-2.0.0 2x"
            alt="Swansea University"
            width="185"
            height="116"
        />
    </picture>
</a>

            <button id="mobile-site-search-button" class="primary-nav-search-anchor" type="button" aria-label="show mobile site search" aria-expanded="false" aria-controls="mobile-site-search"></button>
        </div>

        <div class="container-lg primary-nav-toggler-content-container">   
            <div class="collapse navbar-collapse primary-nav-toggler-content" id="primary-nav-content">
                <!-- START .primary-nav-utility holds lang and contextual -->
                <div class="primary-nav-utility">
    <ul class="primary-nav-utility-links">

    <li>
        <a href="/jobs-at-swansea/" title="Jobs at Swansea University">Jobs</a>
    </li>

    <li>
        <a class="utility-links-recite-me-link" href="#" onclick="return false;" title="Accessibility Tools">Accessibility Tools</a>
    </li>

    <li>
        <a href="https://myuni.swansea.ac.uk/">Current Students</a>
    </li>

    <li>
        <a href="https://staff.swansea.ac.uk/">Staff</a>
    </li>

    <li>
        <a href="http://www.swanseauniversity.com.cn/" aria-label="A link to information in Chinese about Swansea University">中文</a>
    </li>

    <li>
        <a href="/cy/busnes/newyddion/2021/cydweithio-i-sicrhau-dyfodol-disglair-a-ffyniannus-ar-ol-y-pandemig.php" lang="cy-GB">Cymraeg</a>
    </li>

</ul>
    <div class="primary-nav-breadCrumb d-md-none">
        <ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadCrumb-list">
<li class="first" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/">
            <span itemprop="name">Home</span>
        </a>
        <meta itemprop="position" content="1" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/business-and-industry/">
            <span itemprop="name">Business</span>
        </a>
        <meta itemprop="position" content="2" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/business-and-industry/news/">
            <span itemprop="name">Business News and Features</span>
        </a>
        <meta itemprop="position" content="3" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/business-and-industry/news/2021/">
            <span itemprop="name">2021</span>
        </a>
        <meta itemprop="position" content="4" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="">
            <span itemprop="name">Working collectively to ensure a bright and prosperous post-pandemic future</span>
        </a>
        <meta itemprop="position" content="5" />
    </li>
</ol>
    </div>
                </div>
                <!-- END .primary-nav-utility -->
    <ul class="navbar-nav" role="menu">
    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Study</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/our-open-days/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Open Days at Swansea</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/swansea-university-students-on-bay-campus.jpg" alt="Three students walking through Bay Campus in the Sun"  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">We can&#039;t wait to meet you!</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/our-open-days/">Visit us</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/undergraduate/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Undergraduate</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/undergraduate/courses/" role="menuitem" class="nav-link">Courses</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/accommodation/" role="menuitem" class="nav-link">Accommodation</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/clearing/" role="menuitem" class="nav-link">Clearing at Swansea</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/parents/" role="menuitem" class="nav-link">Parents and Guardians Guide to University</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/open-days/" role="menuitem" class="nav-link">Open Days</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/undergraduate/how-to-apply/" role="menuitem" class="nav-link">How to Apply</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/undergraduate/scholarships/" role="menuitem" class="nav-link">Scholarships and Bursaries</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/undergraduate/contact-admissions/" role="menuitem" class="nav-link">Make an Undergrad Enquiry</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/keep-in-touch/" role="menuitem" class="nav-link">Keep in Touch</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/postgraduate/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Postgraduate</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/taught/" role="menuitem" class="nav-link">Taught Courses</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/research/" role="menuitem" class="nav-link">Research Programmes</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/open-days/" role="menuitem" class="nav-link">Open Days</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/apply/" role="menuitem" class="nav-link">How to Apply</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/scholarships/" role="menuitem" class="nav-link">Scholarships and Bursaries</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-university/" role="menuitem" class="nav-link">Your University</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/contact-admissions/" role="menuitem" class="nav-link">Make a Postgrad Enquiry</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/keep-in-touch/" role="menuitem" class="nav-link">Keep in Touch</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/international-students/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">International Students</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/international-student-courses/" role="menuitem" class="nav-link">Courses</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/international-student-courses/how-to-apply/" role="menuitem" class="nav-link">How to Apply</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/my-finances/international-scholarships/" role="menuitem" class="nav-link">Scholarships and Bursaries</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/my-country/" role="menuitem" class="nav-link">Your Country Information</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-campuslife/" role="menuitem" class="nav-link">Support for International Students</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/goglobal/" role="menuitem" class="nav-link">Study Abroad &amp; Exchange</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/english-language-training-services/" role="menuitem" class="nav-link">English Language Training Services</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-college/" role="menuitem" class="nav-link">International Pathways</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international/contact-us/" role="menuitem" class="nav-link">Ask Us a Question</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/study/student-life/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Student Life</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/" role="menuitem" class="nav-link">Study</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/why-study-in-swansea/" role="menuitem" class="nav-link">Why Swansea</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/our-student-stories/" role="menuitem" class="nav-link">Our Student Stories</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/life-on-campus/" role="menuitem" class="nav-link">Life on Campus</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/" role="menuitem" class="nav-link">Sport</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sustainability/get-involved/" role="menuitem" class="nav-link">Sustainability - Get Involved</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cultural-institute/" role="menuitem" class="nav-link">Arts and Culture</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/student-life/susu/" role="menuitem" class="nav-link">Swansea University Students' Union</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/virtual-tour-stand-alone/" role="menuitem" class="nav-link">Virtual tours</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/freshers/" role="menuitem" class="nav-link">What is Freshers?</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/student-services/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Student Services</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/library/" role="menuitem" class="nav-link">Library</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/campuslife/" role="menuitem" class="nav-link">CampusLife</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sea/" role="menuitem" class="nav-link">Swansea Employability Academy (SEA)</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://myuni.swansea.ac.uk/employability-enterprise/student-enterprise/" role="menuitem" class="nav-link">Student Enterprise</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/academic-success/" role="menuitem" class="nav-link">Centre for Academic Success</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/academi-hywel-teifi/" role="menuitem" class="nav-link">Welsh on Campus</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/student-support-services/" role="menuitem" class="nav-link">Student Wellbeing</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/international/">International </a>
</li>

    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Our Research</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/research/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Our Research</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/kaleidoscope-image-no-words.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/kaleidoscope-image-no-words.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/kaleidoscope-image-no-words.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/kaleidoscope-image-no-words.jpg" alt=""  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">Find out more about our world-changing research</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/research/">Read more</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/research-with-us/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Research with us</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-with-us/postgraduate-research/" role="menuitem" class="nav-link">Supporting your postgraduate research journey</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/research/" role="menuitem" class="nav-link">Find a postgraduate research programme</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/research/apply/" role="menuitem" class="nav-link">How to apply for your Postgraduate Research programme</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-with-us/postgraduate-research/training-and-skills-development-programme/" role="menuitem" class="nav-link">Training and Development for Research Students and Supervisors</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/explore-our-research/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Explore our research</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-highlights/" role="menuitem" class="nav-link">Research Highlights</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/explore-our-research/research-in-the-faculties/" role="menuitem" class="nav-link">Research in the faculties</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/momentum-magazine/" role="menuitem" class="nav-link">Momentum Magazine</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/podcasts/" role="menuitem" class="nav-link">Global Challenges Podcast Series</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/discover-our-expertise/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Discover our expertise</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/discover-our-expertise/" role="menuitem" class="nav-link">Find a Researcher</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://cronfa.swan.ac.uk/" role="menuitem" class="nav-link">Find a research publication</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/business-and-industry/access-our-research-development/" role="menuitem" class="nav-link">Access our Research Expertise</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/research-environment/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Research Environment</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-integrity-ethics-governance/" role="menuitem" class="nav-link">Research Integrity: Ethics and Governance</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-impact/" role="menuitem" class="nav-link">Research Impact</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-environment/research-staff-development/" role="menuitem" class="nav-link">Training and Development</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/masi/" role="menuitem" class="nav-link">Morgan Advanced Studies Institute (MASI) </a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/civic-mission/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Our Civic Mission</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/swansea-science-festival/" role="menuitem" class="nav-link">Swansea Science Festival</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://beinghumanfestival.org/" role="menuitem" class="nav-link">Being Human Festival</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://orielscience.co.uk/" role="menuitem" class="nav-link">Oriel Science</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.welshcopper.org.uk/en/index.htm" role="menuitem" class="nav-link">A World of Welsh Copper</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/business-and-industry/">Business</a>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/alumni/">Alumni</a>
</li>

    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Your University</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/press-office/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Press Office</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/press-office-mega-menu-cta.png" alt="Female student working with steel"  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">Latest news and research</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/press-office/">Press Office</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/the-university/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Your University</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/about-us/" role="menuitem" class="nav-link">About us</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-university/location/" role="menuitem" class="nav-link">How to Find Us</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/awards/" role="menuitem" class="nav-link">University Awards and Rankings</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-university/faculties/" role="menuitem" class="nav-link">Our Faculties</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/press-office/" role="menuitem" class="nav-link">Press Office</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/jobs-at-swansea/" role="menuitem" class="nav-link">Job Opportunities and Working At Swansea</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sustainability/" role="menuitem" class="nav-link">Sustainability at Swansea University</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/travel/" role="menuitem" class="nav-link">Travel to and from Campus</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/contact-us/" role="menuitem" class="nav-link">Contact Us</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/sport/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Sport</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/get-active/" role="menuitem" class="nav-link">Get ACTIVE</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/social-leagues/" role="menuitem" class="nav-link">Social Leagues</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/clubs/" role="menuitem" class="nav-link">Club Sport</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/high-performance/" role="menuitem" class="nav-link">Performance</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swanseabaysportspark.wales/" role="menuitem" class="nav-link">Facilities</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/sponsor-us/" role="menuitem" class="nav-link">Sponsorship</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/scholarships-and-tass/" role="menuitem" class="nav-link">Scholarships</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/news-and-updates/" role="menuitem" class="nav-link">News</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/life-on-campus/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Life on Campus</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/accommodation/" role="menuitem" class="nav-link">Accommodation</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/catering/" role="menuitem" class="nav-link">Catering</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cultural-institute/" role="menuitem" class="nav-link">Arts and Culture</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/life-on-campus/the-great-hall/" role="menuitem" class="nav-link">The Great Hall</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.taliesinartscentre.co.uk/en/" role="menuitem" class="nav-link">Taliesin</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cultural-institute/taliesin-create/" role="menuitem" class="nav-link">Taliesin Create</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.egypt.swan.ac.uk/" role="menuitem" class="nav-link">Egypt Centre</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/life-on-campus/our-grounds/" role="menuitem" class="nav-link">Our Grounds</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/music/" role="menuitem" class="nav-link">Musical Opportunities</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/virtual-tour-stand-alone/" role="menuitem" class="nav-link">Virtual Tour</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/the-university/faculties/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Our Faculties</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/humanities-and-socialsciences/" role="menuitem" class="nav-link">Faculty of Humanities and Social Sciences</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/medicine-health-life-science/" role="menuitem" class="nav-link">Faculty of Medicine, Health and Life Science </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/science-and-engineering/" role="menuitem" class="nav-link">Faculty of Science and Engineering</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-college/" role="menuitem" class="nav-link">The College</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/the-university/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Academies</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/hwa/" role="menuitem" class="nav-link">Health and Wellbeing Academy </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/masi/" role="menuitem" class="nav-link">Morgan Advanced Studies Institute (MASI) </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sea/" role="menuitem" class="nav-link">Swansea Employability Academy (SEA)</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/academi-hywel-teifi/" role="menuitem" class="nav-link">Academi Hywel Teifi</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/inclusivity-academy/" role="menuitem" class="nav-link">Swansea Academy of Inclusivity</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/iss/salt/" role="menuitem" class="nav-link">SALT</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/press-office/news-events/">News and Events</a>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/student-support-services/">Support &amp; Wellbeing</a>
</li>

</ul>            </div>
        </div>
    </nav>

<!-- END .primary-nav -->

    <form id="mobile-site-search" class="form-inline primary-nav-form" method="GET" role="search" aria-label="mobile site search" action="/search/">
        <input class="primary-nav-search" type="text" id="mobile-search-input" name="q" placeholder="Search Swansea University" aria-label="Search" />
        <input name="c" value="www-en-meta" type="hidden" />
        <input class="primary-nav-search-button btn btn-primary-alt" type="submit" value="Search" />
    </form>

    <script>
    SU.injectedScripts.push(function ($) {
        $('#mobile-search-input').autocompletion({
            datasets: {
                organic: {
                collection: 'www-en-meta',
                profile   : '_default',
                program   : 'https://swansea.funnelback.co.uk/s/suggest.json',
            }
        },
        length: 3
      });
    });
</script>

    <main id="main" tabindex="-1">

    <div id="contentHeader" class="content-header">
        <div class="container">
            <div class="row">
                <div class="col-12 offset-lg-2 col-lg-10 breadCrumb-holder">
                    <div class="desktop-breadcrumb">
                        <ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadCrumb-list">
<li class="first" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/">
            <span itemprop="name">Home</span>
        </a>
        <meta itemprop="position" content="1" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/business-and-industry/">
            <span itemprop="name">Business</span>
        </a>
        <meta itemprop="position" content="2" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/business-and-industry/news/">
            <span itemprop="name">Business News and Features</span>
        </a>
        <meta itemprop="position" content="3" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/business-and-industry/news/2021/">
            <span itemprop="name">2021</span>
        </a>
        <meta itemprop="position" content="4" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="">
            <span itemprop="name">Working collectively to ensure a bright and prosperous post-pandemic future</span>
        </a>
        <meta itemprop="position" content="5" />
    </li>
</ol>
                    </div>
                </div>
                <div class="col-12 offset-lg-2 col-lg-10">
                    <h1 class="content-header-heading">Working collectively to ensure a bright and prosperous post-pandemic future</h1>
                </div>
                <div class="col-12 col-sm-6 d-lg-none mb-3">
                    
<div class="dropdown">
    <a class="mobile-contextual-nav-toggle" href="#" role="button" id="mobile-contextual-nav" data-toggle="dropdown" data-display="static" aria-haspopup="true" aria-expanded="false">
        Related pages    </a>
    <div class="dropdown-menu" aria-labelledby="mobile-contextual-nav">
        <ul class="contextual-nav ml-2 ml-lg-0">
            <li><a class="dropdown-item" href="/business-and-industry/">Home</a></li><li><a class="dropdown-item" href="/business-and-industry/access-our-research-development/">Access our Research Expertise</a></li><li><a class="dropdown-item" href="/business-and-industry/recruit-our-talent/">Recruit our Talent</a></li><li><a class="dropdown-item" href="/business-and-industry/develop-your-workforce/">Develop your Workforce</a></li><li><a class="dropdown-item" href="/business-and-industry/commercial-and-events-services/">Utilise our Commercial, Sponsorship and Events Services</a></li><li><a class="dropdown-item" href="/business-and-industry/facilities-hire/">Hire Our Facilities </a></li><li><a class="dropdown-item" href="/business-and-industry/linc/">Swansea University LINC Network</a></li><li><a class="dropdown-item" href="/business-and-industry/news/">Business News and Features</a>
<ul class="multilevel-linkul-0">
<li><a class="dropdown-item" href="/business-and-industry/news/2021/">2021</a></li>
<li><a class="dropdown-item" href="/business-and-industry/news/2020/">2020</a></li>
<li><a class="dropdown-item" href="/business-and-industry/news/2019/">2019</a></li>

</ul>

</li><li><a class="dropdown-item" href="/business-and-industry/newsletter/">Sign up to our Business Newsletter</a></li><li><a class="dropdown-item" href="/business-and-industry/contact-us/">Contact our Business Engagement team</a></li>
        </ul>
    </div>
</div>

                </div>
            </div>
        </div>
    </div>

    
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-10 order-last">
                <div class="row">
            <div class="container">
    <div class="row">
    <div class="news-article-title-and-body-text col-xl-8">

    <figure>
        <div class="news-article-title-and-body-text-image">
            <img src="/business-and-industry/news/2021/VC-article-750x345.jpg" width="750" height="345"  alt=""  />
        </div>
        </figure>

    <div class="news-article-title-and-body-text-description"><p>Over the last two years, organisations across every sector have grappled with the dual impacts of Brexit and a global pandemic. Here, Vice-Chancellor Professor Paul Boyle considers Swansea University’s role in the recovery of our region and nation, and the opportunities for greater collaboration between universities and industry partners in the months and years to come.</p></div>

    <div class="news-article-title-and-body-text-article-body">
        <p>Just over a century ago, Swansea University was founded by industry for industry. While our physical footprint has evolved over the course of one hundred years, today we remain true to the ambitions of our founders. We work with industrial, commercial and private sector partners for the benefit of our region and nation, with the principles of innovation and collaboration guiding our strategic <a href="https://www.swansea.ac.uk/the-university/vision/" target="_blank">vision and purpose</a>.</p>
<p>With access to some of the brightest academic minds in the world, our University has successfully collaborated with thousands of public, private and third sector organisations, applying our world-leading research expertise and global reach to solve the key challenges of today and tomorrow. We are proud to play an active role in supporting regional development within South West Wales, and have supported the growth and economic prosperity of our region through our collaborative work with many local partners.</p>
<p>As we continue to adapt to a new professional landscape, impacted by both Brexit and a global pandemic, we also know that effective, cross-sector collaboration is more critical now than ever before. The past twelve months have demonstrated the incredible agility and resilience of our business community, our partners and our funders. By working together, we have risen to meet the ongoing demands of Covid-19. Together, we have mobilised our knowledge and expertise to <a href="https://www.swansea.ac.uk/press-office/news-events/news/2020/06/recovering-from-coronavirus-new-ventilator-can-save-lives-and-create-jobs-.php" target="_blank">develop life-saving ventilators</a>, <a href="https://www.swansea.ac.uk/press-office/news-events/news/2020/04/from-solar-to-sanitiser--uni-team-producing-5000-litres-a-week-for-nhs.php" target="_blank">manufacture hand gels</a>, <a href="https://www.swansea.ac.uk/press-office/news-events/news/2020/04/funding-for-team-to-test-speed-clean-of-ambulances-carrying-covid-19-patients.php" target="_blank">sanitise ambulances</a>, <a href="https://www.swansea.ac.uk/press-office/news-events/news/2020/04/coronavirus-lockdown-new-study-into-the-effect-on-physical-activity-and-wellbeing.php" target="_blank">study physical and wellbeing impacts of the pandemic</a>,&nbsp;<a href="https://www.swansea.ac.uk/press-office/news-events/news/2020/04/how-your-coronadiary-could-help-us-understand-more-about-living-through-a-pandemic.php" target="_blank">diarise COVID-19 experiences</a> and <a href="https://swansea-covid19.hubbub.net/" target="_blank">raise funds for those most in need</a>.<br> <br>The past year has shown us what can be achieved through collaboration, even within the most challenging of circumstances. At Swansea University, we are keen to apply those lessons in support of the recovery and development of our region, our nation and our planet, by harnessing the ambition and sense of urgency which have driven the national response to Covid-19.</p>
<p>I believe that our University has so much to offer our business community, and I hope that you will consider working with us as we seek to support the future economic growth of our region.</p>
<h4>A range of expertise</h4>
<p>My first academic role was as a young lecturer within the Department of Geography at Swansea University in the 1990s. Back then, I was struck not only by the warmth of the welcome, but also by the breadth and diversity of the University’s research portfolio. Today, Swansea University is ranked as a top-30 research intensive institution within the UK, with a track record for producing <a href="https://www.swansea.ac.uk/research/research-highlights/" target="_blank">world-leading research that delivers major impact in the real world</a>.</p>
<p>We know that the research and innovation sector is vital to our region’s overall economic productivity. It brings significant economic, social and health benefits, underpinning industries and creating jobs and products that enhance our quality of life and enrich our cultural wellbeing. There are also genuine opportunities for our region to take a leading role in the policy priorities highlighted by current Welsh and UK Governments, namely: post-pandemic recovery; building sustainable communities; achieving carbon net zero and nurturing productive and competitive businesses.</p>
<p>By working together across the region, we can mobilise our knowledge and experience to meet the grand challenges of the day, both local and global. With highly trained, enthusiastic, and knowledgeable staff and access to a growing worldwide network of over 500 research partners, our University is well-placed to provide your organisation with <a href="https://www.swansea.ac.uk/business-and-industry/access-our-research-development/" target="_blank">opportunities for meaningful collaboration</a>.</p>
<p>From <a href="https://www.agorip.com/" target="_blank">bringing new innovation to life </a>and working with organisations to <a href="https://www.astutewales.com/en/" target="_blank">understand and solve industry challenges</a>, to driving a <a href="https://www.specific.eu.com/work-with-us/" target="_blank">reduction in our region’s carbon footprint</a>, Swansea University has a wide portfolio of demand-led&nbsp;<a href="https://www.swansea.ac.uk/business-and-industry/access-our-research-development/projects/" target="_blank">industry-focused projects</a> that can help and support your organisation to face today’s key challenges.</p>
<p>Along with our significant research expertise, our University is recognised for our high-quality teaching, which helps to nurture the confident, adaptable, and highly-skilled employees of tomorrow. We can provide your organisation with&nbsp;<a href="https://www.swansea.ac.uk/business-and-industry/recruit-our-talent/" target="_blank">access to a work-ready and talented pool of students and graduates</a> for placement and employment opportunities. We also offer<a href="https://www.swansea.ac.uk/business-and-industry/develop-your-workforce/" target="_blank"> professional training and skills development</a> courses covering a diverse range of disciplines, and delivered by experts in their fields.</p>
<p>As we plan for our post-pandemic future, we want to work with you to make the most of the considerable opportunities available to us, to secure vital future funding for our region.</p>
<h4>A gateway to funding</h4>
<p>Our strong and longstanding relationships with funders and investors are critical to the inflow of funding to South West Wales. Our University is well-placed to source a wide range of support programmes, incentivisation schemes, and funding for partnership building and R&amp;D and innovation-related activity.</p>
<p>In fact, despite the challenges of 2020/21, I am proud that Swansea University has collaborated with a wide range of partners to secure <strong>£62.6m in research and innovation funding awards</strong> (cash contribution) in the first eight months of the 20/21 academic year; up from just £38.3m at the same point last year. This funding will support projects that tackle Covid-19, accelerate innovation across the region, address major local and global challenges and drive prosperity within South West Wales.</p>
<p>For organisations based within our region, funding is available at many levels; from a few thousand pounds for entry-level projects, to multi-million-pound grants for projects which address global challenges and produce significant social and economic impact.</p>
<p>There is also a major emerging opportunity to boost innovation across Wales via the <a href="https://www.swansea.ac.uk/business-and-industry/access-our-research-development/rwif/" target="_blank">Research Wales Innovation Fund</a>, which aims to close Wales’ productivity gap with the rest of UK. This funding provides increased capacity and support for the business community to work directly with us on&nbsp;<a href="https://www.swansea.ac.uk/business-and-industry/access-our-research-development/research-collaborations/smart-and-knowledge-transfer-partnerships/" target="_blank">knowledge exchange projects</a>, industry-led funding applications and workforce development.</p>
<p>Funding is also still in place for the EU-funded&nbsp;<a href="https://ec.europa.eu/info/horizon-europe_en" target="_blank">Horizon Europe</a> scheme, with the UK continuing to have access to the EU’s €95.5 billion funding programme for research and innovation. I would strongly encourage our business community to capitalise on the opportunities provided by EU-funded projects that are still offering support to organisations across the region.</p>
<p>Finally, although we will no longer have access to the European Structural and Investment Fund (ESIF) that has long-supported regional economic and social development in Wales, the UK Government has announced details of the new&nbsp;<a href="https://commonslibrary.parliament.uk/research-briefings/cbp-8527/" target="_blank">Shared Prosperity Fund</a> (SPF) which will eventually take its place. A £220 million pilot scheme for the SPF (the <a href="https://www.gov.uk/government/publications/uk-community-renewal-fund-prospectus" target="_blank">UK Community Renewal Fund</a>) is currently open, and – like many organisations across our region – here at Swansea University, we are currently in the process of shaping and submitting our Local Authority bids.</p>
<p>While Swansea University will continue to promote the strength of the R&amp;D sector in Wales at EU, UK and Welsh Government levels, we know that the funding landscape is changing post-Brexit, with new opportunities to attract research, development and innovation support into our region. For funders in the UK, research that is rooted in the needs of the whole region and its citizens is clearly an emerging priority; effective collaboration between universities, the private sector and other local stakeholders is the only way that we can achieve this.</p>
<h4>Collaborate with us</h4>
<p>There are so many ways in which we can work with your organisation, and we stand ready to share our expertise, our global reach and our talent pool. You can&nbsp;<a href="https://www.swansea.ac.uk/business-and-industry/contact-us/" target="_blank">contact our engagement team</a> to discuss the&nbsp;<a href="https://www.swansea.ac.uk/business-and-industry/" target="_blank">range of support and funding</a> that is currently available to organisations within our region, Wales and beyond. As well as aiming to understand your organisation, and identify key challenges and areas of mutual interest, our engagement team can signpost you to relevant stakeholders, support applications for funding and help open the door to new relationships.</p>
<p>While in-person events remain on hold, our&nbsp;<a href="https://www.swansea.ac.uk/business-and-industry/linc/" target="_blank">Swansea University LINC business network</a> continues to operate in a virtual capacity. You can also engage with us, and with organisations from across the region, via our <a href="https://www.linkedin.com/groups/8178988/?utm_source=LinkedIn&amp;utm_medium=social&amp;utm_campaign=SocialSignIn&amp;utm_content=Covid19" target="_blank">LinkedIn group</a>, where we share details of any upcoming webinars, along with the latest on COVID-19 funding and the support that is available.</p>
<p>Regardless of the sector in which we operate, our world has changed dramatically over the course of the past year. At Swansea University, our commitment to supporting new innovations, new jobs, new businesses, and to upskilling workforces for the challenges of tomorrow, remains a priority. I very much look forward to working with our business community over the coming year, as collectively we work to ensure a bright and prosperous post-pandemic future for our region.</p>
    </div>

<div class="news-article-share-story">
    <h3 class="news-article-share-story-heading">Share Story</h3>

    <ul class="news-article-share-story-social-links social-links">
        <li class="social-item-facebook">
            <a class="social-link" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.swansea.ac.uk%2Fbusiness-and-industry%2Fnews%2F2021%2Fworking-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" target="_blank">Facebook (new window)</a>
        </li>

        <li class="social-item-twitter">
            <a class="social-link" href="https://twitter.com/intent/tweet?text=Working%20collectively%20to%20ensure%20a%20bright%20and%20prosperous%20post-pandemic%20future%20https%3A%2F%2Fwww.swansea.ac.uk%2Fbusiness-and-industry%2Fnews%2F2021%2Fworking-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" target="_blank">Twitter (new window)</a>
        </li>

        <li class="social-item-linkedin">
            <a class="social-link" href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.swansea.ac.uk%2Fbusiness-and-industry%2Fnews%2F2021%2Fworking-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" target="_blank">LinkedIn (new window)</a>
        </li>
    </ul>
</div>

</div>

    <div class="col-xl-4">
    <div class="news-article-meta-data">
        <ul>
            <li><i class="fas fa-calendar-alt"></i> Monday 14 June 2021 13:12 BST</li>

            <li class="news-article-meta-data-author-name"><i class="fa fa-portrait"></i> Professor Paul Boyle</li>

            <li><i class="fa fa-building"></i> Swansea University</li>

            <li><a href="mailto:"><i class="far fa-envelope"></i> </a></li>

            <li><i class="fas fa-phone fa-flip-horizontal"></i> </li>
        </ul>

        <div class="d-none d-xl-block">
<div class="news-article-share-story">
    <h3 class="news-article-share-story-heading">Share Story</h3>

    <ul class="news-article-share-story-social-links social-links">
        <li class="social-item-facebook">
            <a class="social-link" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.swansea.ac.uk%2Fbusiness-and-industry%2Fnews%2F2021%2Fworking-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" target="_blank">Facebook (new window)</a>
        </li>

        <li class="social-item-twitter">
            <a class="social-link" href="https://twitter.com/intent/tweet?text=Working%20collectively%20to%20ensure%20a%20bright%20and%20prosperous%20post-pandemic%20future%20https%3A%2F%2Fwww.swansea.ac.uk%2Fbusiness-and-industry%2Fnews%2F2021%2Fworking-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" target="_blank">Twitter (new window)</a>
        </li>

        <li class="social-item-linkedin">
            <a class="social-link" href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.swansea.ac.uk%2Fbusiness-and-industry%2Fnews%2F2021%2Fworking-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php" target="_blank">LinkedIn (new window)</a>
        </li>
    </ul>
</div>
        </div>

    </div>
</div>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.swansea.ac.uk/business-and-industry/news/2021/working-collectively-to-ensure-a-bright-and-prosperous-post-pandemic-future.php"
  },
  "headline": "Working collectively to ensure a bright and prosperous post-pandemic future",
  "image": [
    "https://www.swansea.ac.uk/business-and-industry/news/2021/VC-article-750x345.jpg",
    "https://www.swansea.ac.uk/business-and-industry/news/2021/VC-article.jpg"
   ],
  "datePublished": "2021-06-14T13:12:00+0100",
  "dateModified": "2022-09-21T17:15:48+0100",
  "author": {
    "@type": "Person",
    "name": "Professor Paul Boyle"
  },
   "publisher": {
    "@type": "Organization",
    "name": "Swansea University",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.swansea.ac.uk/_assets/images/logos/swansea-university-2017.en.png",
      "height": "385",
      "width": "693"
    }
  }
}
</script>


    </div>
</div>
                    </div>
            </div>
            <div class="d-none d-lg-block col-md-2 order-first">
                <nav aria-label="Related pages">
                    <ul class="contextual-nav">
    <li><a href="/business-and-industry/">Home</a></li><li><a href="/business-and-industry/access-our-research-development/">Access our Research Expertise</a></li><li><a href="/business-and-industry/recruit-our-talent/">Recruit our Talent</a></li><li><a href="/business-and-industry/develop-your-workforce/">Develop your Workforce</a></li><li><a href="/business-and-industry/commercial-and-events-services/">Utilise our Commercial, Sponsorship and Events Services</a></li><li><a href="/business-and-industry/facilities-hire/">Hire Our Facilities </a></li><li><a href="/business-and-industry/linc/">Swansea University LINC Network</a></li><li><a href="/business-and-industry/news/">Business News and Features</a>
<ul class="multilevel-linkul-0">
<li><a href="/business-and-industry/news/2021/">2021</a></li>
<li><a href="/business-and-industry/news/2020/">2020</a></li>
<li><a href="/business-and-industry/news/2019/">2019</a></li>

</ul>

</li><li><a href="/business-and-industry/newsletter/">Sign up to our Business Newsletter</a></li><li><a href="/business-and-industry/contact-us/">Contact our Business Engagement team</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    </main>


    <footer>
        <div class="container">
            <div class="row">
                <div class="footer-links-info">
                    <ul class="footer-links-list">
<li class="footer-links-list-item"><a href="/contact-us/">Contact Us</a></li><li class="footer-links-list-item"><a href="/jobs-at-swansea/">Jobs</a></li><li class="footer-links-list-item"><a href="/the-university/faculties/">Faculties</a></li><li class="footer-links-list-item"><a href="/press-office/">Press</a></li><li class="footer-links-list-item"><a href="/about-us/safety-and-security/health-and-safety/">Health &amp; Safety</a></li><li class="footer-links-list-item"><a href="/disclaimer-and-copyright/">Disclaimer &amp; Copyright</a></li><li class="footer-links-list-item"><a href="/system/site-map/">Site Map</a></li><li class="footer-links-list-item"><a href="/privacyandcookies/">Privacy &amp; Cookies</a></li><li class="footer-links-list-item"><a href="/media/Modern-Slavery-Statement.pdf">Modern Slavery Statement</a></li><li class="footer-links-list-item"><a href="/the-university/accessibility/swansea-ac-uk/">Accessibility Statement</a></li>
                    </ul>
                    <ul class="footer-info-list">
                        <li class="footer-info-list-item">Swansea University is a registered charity, No. 1138342</li>
                    </ul>
                </div>
    <div class="footer-social">
    <ul class="footer-social-list">

        <li class="footer-social-list-item">
            <a href="https://www.facebook.com/swanseauniversity" aria-label="Swansea University on Facebook">
                <i class="fab fa-facebook-square"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.instagram.com/swanseauni/?hl=en" aria-label="Swansea University on Instagram">
                <i class="fab fa-instagram"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://twitter.com/SwanseaUni" aria-label="Swansea University on Twitter">
                <i class="fab fa-twitter"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.tiktok.com/@swanseauni" aria-label="Swansea University on TikTok">
                <i class="fab fa-tiktok"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.youtube.com/user/SwanseaUniVideo" aria-label="Swansea University on YouTube">
                <i class="fab fa-youtube"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.flickr.com/photos/swanseauniversity/" aria-label="Swansea University on Flickr">
                <i class="fab fa-flickr"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.linkedin.com/school/swansea-university/" aria-label="Swansea University on LinkedIn">
                <i class="fab fa-linkedin"></i>
            </a>
        </li>


    </ul>
</div>

            </div>
        </div>
    </footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
<script src="https://ik.imagekit.io/s1sp3stox/_web/js/www-bundle.min.js?v=b348f1a3104466ceba9ead35abeb8974&ik-sdk-version=php-2.0.0"></script>

</body>
</html>
