<!DOCTYPE html>
<html class="no-js" lang="cy-GB" prefix="og: http://ogp.me/ns#">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-2764516-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-2764516-1');
  gtag('config', 'UA-2764516-41');
</script>
            <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/fonts/futura/hinted-FuturaPTBold-Reg.woff2?ik-sdk-version=php-2.0.0" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/fonts/futura/hinted-FuturaPTBook-Reg.woff2?ik-sdk-version=php-2.0.0" as="font" type="font/woff2" crossorigin>

    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/js/www-bundle.min.js?v=b348f1a3104466ceba9ead35abeb8974&ik-sdk-version=php-2.0.0" as="script">

    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/css/general.min.css?v=cadd65eee68e59e01d07512b07c275b2&ik-sdk-version=php-2.0.0" as="style">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta property="su:section-id" content="86516" />
    






    <meta name="description" content="Mae megalodon a ddarganfuwyd yn y 1860au wedi galluogi tîm rhyngwladol o wyddonwyr dan arweiniad Prifysgol Zurich, Prifysgol Abertawe a&#039;r Coleg Milfeddygaeth Brenhinol i greu&#039;r model 3D mwyaf cyflawn hyd yn hyn o fegalodon – y siarc mwyaf sydd wedi byw erioed.">
<meta property="su:page-type" content="Eitem Newyddion">
<meta property="og:title" content="Model 3D newydd yn datgelu bod megalodon yn pwyso mwy na 61 dunnell ac yn gallu bwyta morfilod danheddog cyfan
">
<meta property="og:type" content="article">
<meta property="og:url" content="https://www.swansea.ac.uk/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/model-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php">
<meta property="og:description" content="Mae megalodon a ddarganfuwyd yn y 1860au wedi galluogi tîm rhyngwladol o wyddonwyr dan arweiniad Prifysgol Zurich, Prifysgol Abertawe a&#039;r Coleg Milfeddygaeth Brenhinol i greu&#039;r model 3D mwyaf cyflawn hyd yn hyn o fegalodon – y siarc mwyaf sydd wedi byw erioed.">
<meta property="og:image" content="https://www.swansea.ac.uk/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/Megalodon---picture-credit-J.-J.-Giraldo_Thumb.jpg">
<meta property="og:image:alt" content="Darlun o&#039;r megalodon ">
<meta property="og:locale" content="cy_GB">
<meta property="og:site_name" content="Prifysgol Abertawe">
    <title>Model 3D newydd yn datgelu bod megalodon yn pwyso mwy na 61 dunnell ac yn gallu bwyta morfilod danheddog cyfan
 - Prifysgol Abertawe</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/icons/apple-touch-icon.png?ik-sdk-version=php-2.0.0">
        <link rel="icon" type="image/png" sizes="32x32" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon-32x32.png?ik-sdk-version=php-2.0.0">
    <link rel="icon" type="image/png" sizes="16x16" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon-16x16.png?ik-sdk-version=php-2.0.0">
    <link rel="manifest" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/site.webmanifest?ik-sdk-version=php-2.0.0">
    <link rel="mask-icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/safari-pinned-tab.svg?ik-sdk-version=php-2.0.0" color="#5bbad5">
    <link rel="shortcut icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon.ico?ik-sdk-version=php-2.0.0">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/browserconfig.xml?ik-sdk-version=php-2.0.0">
    <meta name="theme-color" content="#ffffff">

        <link rel="stylesheet" href="https://ik.imagekit.io/s1sp3stox/_web/css/general.min.css?v=cadd65eee68e59e01d07512b07c275b2&ik-sdk-version=php-2.0.0" type="text/css" media="all" />

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        function isAtLeastPartiallyVisible(el) {
            const rect = el.getBoundingClientRect();
            return rect.top < window.innerHeight && rect.bottom >= 0;
        }

        document.querySelectorAll('img').forEach(function(img) {
            if (isAtLeastPartiallyVisible(img)) {
                img.removeAttribute('loading');
            } else {
                img.setAttribute('loading', 'lazy');
            }
        });
    }, false);
</script>

    <script src="https://kit.fontawesome.com/026410dcd9.js" crossorigin="anonymous"></script>

        <link rel="canonical" href="https://www.swansea.ac.uk/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/model-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" />

    <script>
      (function(d) {
        var config = {
          kitId: 'lnz6iij',
          scriptTimeout: 3000,
          async: true
        },
        h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
      })(document);
    </script>

    <script>
        var SU = {
            injectedScripts: []
        };
    </script>



<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5MZHZM');</script></head>

<body>

<noscript><iframe title="Google Tag Manager" src="//www.googletagmanager.com/ns.html?id=GTM-5MZHZM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<script data-cookieconsent="ignore">
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag("consent", "default", {
        ad_storage: "denied",
        analytics_storage: "denied",
        wait_for_update: 500
    });
    gtag("set", "ads_data_redaction", true);
</script>

    <header id="banner">
        <div class="container">
            <a class="skip-to-main" href="#main">Sgip i brif cynnwys</a>

    
<a href="/cy/" class="logo logo-www">
    <picture>
        <source type="image/svg+xml" srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy.svg?ik-sdk-version=php-2.0.0" />
        <img
            src="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy.png?ik-sdk-version=php-2.0.0"
            srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy.png?ik-sdk-version=php-2.0.0, https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy@2x.png?ik-sdk-version=php-2.0.0 2x"
            alt="Prifysgol Abertawe"
            width="185"
            height="116"
        />
    </picture>
</a>

    <form method="GET" role="search" aria-label="site search" action="/cy/chwilio/">
        <label for="keywords">Chwiliwch:</label>
        <input type="text" id="keywords" name="q" placeholder="Chwiliwch Prifysgol Abertawe" />
        <input name="c" value="www-cy-meta" type="hidden" />
        <button id="search-button" aria-label="site search button" type="submit" tabindex="0">Search</button>
    </form>

    <script>
    SU.injectedScripts.push(function ($) {
        $('#keywords').autocompletion({
            datasets: {
                organic: {
                collection: 'www-cy-meta',
                profile   : '_default',
                program   : 'https://swansea.funnelback.co.uk/s/suggest.json',
            }
        },
        length: 3
      });
    });
</script>
        
    <ul class="utility-links">

    <li>
        <a href="/cy/y-brifysgol/swyddi-a-gweithio-yn-abertawe/" title="Swyddi ym Mhrifysgol Abertawe">Swyddi</a>
    </li>

    <li>
        <a class="utility-links-recite-me-link" href="#" onclick="return false;" title="Offer Hygyrchedd">Offer Hygyrchedd</a>
    </li>

    <li>
        <a href="https://myuni.swansea.ac.uk/cy/">Myfyrwyr Cyfredol</a>
    </li>

    <li>
        <a href="https://staff.swansea.ac.uk/cy/">Staff</a>
    </li>

    <li>
        <a href="http://www.swanseauniversity.com.cn/" aria-label="Dolen i wybodaeth yn Tsieineaidd am Brifysgol Abertawe">中文</a>
    </li>

    <li>
        <a href="/press-office/news-events/news/2022/08/new-3d-model-reveals-megalodon-weighed-more-than-61-tonnes-and-could-eat-whole-killer-whales.php" lang="en-GB">English</a>
    </li>

</ul>

        </div>
    </header>


    <nav class="navbar navbar-expand-lg primary-nav  yamm ">
        <div class="container">
            <button class="navbar-toggler" data-toggle="collapse" data-target="#primary-nav-content">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30" focusable="false"><title>Menu</title><path stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-miterlimit="10" d="M4 7h22M4 15h22M4 23h22"></path></svg>
            </button>
    
<a href="/cy/" class="logo logo-www">
    <picture>
        <source type="image/svg+xml" srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy.svg?ik-sdk-version=php-2.0.0" />
        <img
            src="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy.png?ik-sdk-version=php-2.0.0"
            srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy.png?ik-sdk-version=php-2.0.0, https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-cy@2x.png?ik-sdk-version=php-2.0.0 2x"
            alt="Prifysgol Abertawe"
            width="185"
            height="116"
        />
    </picture>
</a>

            <button id="mobile-site-search-button" class="primary-nav-search-anchor" type="button" aria-label="dangos chwilotydd y safle symudol" aria-expanded="false" aria-controls="mobile-site-search"></button>
        </div>

        <div class="container-lg primary-nav-toggler-content-container">   
            <div class="collapse navbar-collapse primary-nav-toggler-content" id="primary-nav-content">
                <!-- START .primary-nav-utility holds lang and contextual -->
                <div class="primary-nav-utility">
    <ul class="primary-nav-utility-links">

    <li>
        <a href="/cy/y-brifysgol/swyddi-a-gweithio-yn-abertawe/" title="Swyddi ym Mhrifysgol Abertawe">Swyddi</a>
    </li>

    <li>
        <a class="utility-links-recite-me-link" href="#" onclick="return false;" title="Offer Hygyrchedd">Offer Hygyrchedd</a>
    </li>

    <li>
        <a href="https://myuni.swansea.ac.uk/cy/">Myfyrwyr Cyfredol</a>
    </li>

    <li>
        <a href="https://staff.swansea.ac.uk/cy/">Staff</a>
    </li>

    <li>
        <a href="http://www.swanseauniversity.com.cn/" aria-label="Dolen i wybodaeth yn Tsieineaidd am Brifysgol Abertawe">中文</a>
    </li>

    <li>
        <a href="/press-office/news-events/news/2022/08/new-3d-model-reveals-megalodon-weighed-more-than-61-tonnes-and-could-eat-whole-killer-whales.php" lang="en-GB">English</a>
    </li>

</ul>
    <div class="primary-nav-breadCrumb d-md-none">
        <ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadCrumb-list">
<li class="first" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/">
            <span itemprop="name">Hafan</span>
        </a>
        <meta itemprop="position" content="1" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/">
            <span itemprop="name">Swyddfa'r Wasg</span>
        </a>
        <meta itemprop="position" content="2" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/">
            <span itemprop="name">Newyddion a Digwyddiadau</span>
        </a>
        <meta itemprop="position" content="3" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/">
            <span itemprop="name">Newyddion</span>
        </a>
        <meta itemprop="position" content="4" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/">
            <span itemprop="name">2022</span>
        </a>
        <meta itemprop="position" content="5" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/">
            <span itemprop="name">Awst</span>
        </a>
        <meta itemprop="position" content="6" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="">
            <span itemprop="name">Model 3D newydd yn datgelu bod megalodon yn pwyso mwy na 61 dunnell ac yn gallu bwyta morfilod danheddog cyfan
</span>
        </a>
        <meta itemprop="position" content="7" />
    </li>
</ol>
    </div>
                </div>
                <!-- END .primary-nav-utility -->
    <ul class="navbar-nav" role="menu">
    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Astudio</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/cy/ein-diwrnod-agored/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Diwrnodau Agored yn Abertawe</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/swansea-university-students-on-bay-campus.jpg" alt="Three students walking through Bay Campus in the Sun"  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">Rydyn ni&#039;n disgwyl ymlaen at eich crosawu chi!</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/cy/ein-diwrnod-agored/">Ymweld â ni</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/israddedig/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Israddedig</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/israddedig/cyrsiau/" role="menuitem" class="nav-link">Cyrsiau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/llety/" role="menuitem" class="nav-link">Llety</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/clirio/" role="menuitem" class="nav-link">Clirio ym Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/rhieni-a-gwarcheidwaid/" role="menuitem" class="nav-link">Canllaw Rhieni a Gwarcheidwaid I'r Brifysgol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/diwrnodau-agored/" role="menuitem" class="nav-link">Diwrnodau Agored</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/israddedig/gwneud-cais/" role="menuitem" class="nav-link">Sut i wneud cais</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/israddedig/ysgoloriaethau/" role="menuitem" class="nav-link">Ysgoloriaethau a Bwrsariaethau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/israddedig/cysylltu-a-derbyniadau/" role="menuitem" class="nav-link">Gofynnwch Gwestiwn i Ni</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/cadwch-mewn-cysylltiad/" role="menuitem" class="nav-link">Cadwch mewn cysylltiad</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/ol-raddedig/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Ôl-raddedig</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/addysgir/" role="menuitem" class="nav-link">Cyrsiau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/ymchwil/" role="menuitem" class="nav-link">Rhaglenni Ymchwil</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/diwrnodagored/" role="menuitem" class="nav-link">Diwrnod Agored</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/sut-i-wneud-cais/" role="menuitem" class="nav-link">Sut i Wneud Cais</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/ysgoloriaethau/" role="menuitem" class="nav-link">Ysgoloriaethau a bwrsariaethau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/" role="menuitem" class="nav-link">Y Brifysgol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/cysylltu-a-derbyniadau/" role="menuitem" class="nav-link">Gofynnwch Gwestiwn i Ni</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/cadwch-mewn-cysylltiad/" role="menuitem" class="nav-link">Cadwch mewn cysylltiad</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/astudio/bywyd-myfyriwr/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Bywyd Myfyriwr</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/" role="menuitem" class="nav-link">Astudio</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/pam-astudio/" role="menuitem" class="nav-link">Pam Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/bywyd-y-campws/" role="menuitem" class="nav-link">Bywyd y campws</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/" role="menuitem" class="nav-link">Chwaraeon</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/cynaliadwyedd/cymrwch-ran/" role="menuitem" class="nav-link">Cynaliadwyedd - Cymrwch Ran</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/sefydliad-diwylliannol/" role="menuitem" class="nav-link">Sefydliad Diwylliannol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/bywyd-myfyriwr/undeb/" role="menuitem" class="nav-link">Undeb Myfyrwyr Prifysgol Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/virtual-tour-stand-alone/?lang=cymraeg" role="menuitem" class="nav-link">Taith Rhithwir</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/pythefnos-y-glas/" role="menuitem" class="nav-link">Beth yw Gŵyl y Glas?</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/astudio/adran-gwasanaethau-cymorth-i-fyfyrwyr/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Gwasanaethau i Fyfyrwyr</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ggs/llyfrgelloedd/" role="menuitem" class="nav-link">Llyfrgelloedd ac Archifau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/astudio/adran-gwasanaethau-cymorth-i-fyfyrwyr/bywydcampws/" role="menuitem" class="nav-link">BywydCampws</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/cyflogadwyedd/" role="menuitem" class="nav-link">Academi Cyflogadwyedd Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://myuni.swansea.ac.uk/cy/cyflogadwyedd-menter/menter-myfyrwyr/" role="menuitem" class="nav-link">Menter Myfyrwyr</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/llwyddiant-academaidd/" role="menuitem" class="nav-link">Canolfan Llwyddiant Academaidd</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/academi-hywel-teifi/" role="menuitem" class="nav-link">Academi Hywel Teifi</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/gwasanaethau-cymorth-i-fyfyrwyr/" role="menuitem" class="nav-link">Llesiant myfyrwyr</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/cy/rhyngwladol/">Rhyngwladol</a>
</li>

    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Ein Ymchwil</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">


    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/ymchwil/gwnewch-ymchwil-gyda-ni/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Gwnewch Ymchwil Gyda Ni</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/gwnewch-ymchwil-gyda-ni/ymchwil-ol-raddedig/" role="menuitem" class="nav-link">Cefnogi eich taith ymchwil ôl-raddedig</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/ymchwil/" role="menuitem" class="nav-link">Dod o hyd i raglen ymchwil ol-raddedig</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ol-raddedig/ymchwil/gwneud-cais/" role="menuitem" class="nav-link">Sut i wneud cais am raglen ymchwil Ôl-raddedig</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/gwnewch-ymchwil-gyda-ni/ymchwil-ol-raddedig/training-and-skills-development-programme/" role="menuitem" class="nav-link">Hyfforddiant a Datblygiad i Oruchwylwyr a Myfyrwyr Ymchwil</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/ymchwil/archwiliwch-ein-hymchwil/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Archwiliwch ein hymchwil</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/ein-huchafbwyntiau/" role="menuitem" class="nav-link">Uchafbwyntiau Ymchwil</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/archwiliwch-ein-hymchwil/ymchwil-yn-y-cyfadrannau/" role="menuitem" class="nav-link">Ymchwil yn y cyfadrannau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://online.flippingbook.com/view/398920162/" role="menuitem" class="nav-link">Momentum - ein cylchgrawn ymchwil</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/podlediadau/" role="menuitem" class="nav-link">Archwilio Problemau Byd-eang</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/ymchwil/darganfyddwch-ein-hymchwil/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Darganfyddwch ein hymchwil</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/darganfyddwch-ein-hymchwil/" role="menuitem" class="nav-link">Cyfeiriadur Arbenigedd</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://cronfa.swan.ac.uk/" role="menuitem" class="nav-link">Dod o hyd i bapur ymchwil</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil-arloesi/" role="menuitem" class="nav-link">Manteisio ar ein Harbenigedd ym maes Ymchwil a Datblygu</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/ymchwil/ein-hamgylchedd-ymchwil-/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Ein Hamgylchedd Ymchwil </a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/uniondeb-ymchwil-moeseg-a-llywodraethu/" role="menuitem" class="nav-link">Uniondeb Ymchwil: Moeseg a Llywodraethu </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/ref2014/" role="menuitem" class="nav-link">Effaith ymchwil</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ymchwil/ein-hamgylchedd-ymchwil-/staff-ymchwil/" role="menuitem" class="nav-link">Hyfforddiant a datblygiad</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/sefydliad-astudiaethau-uwch-morgan/" role="menuitem" class="nav-link">Sefydliad Astudiaethau Uwch Morgan (SAUM)</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/ymchwil/cenhadaeth-ddinesig/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false"> Ein Cenhadaeth Ddinesig</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/gwyl-wyddoniaeth-abertawe/" role="menuitem" class="nav-link">Gŵyl Wyddoniaeth Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://beinghumanfestival.org/" role="menuitem" class="nav-link">Gŵyl Bod yn Ddynol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://orielscience.co.uk/" role="menuitem" class="nav-link">Oriel Science</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.welshcopper.org.uk/en/index.htm" role="menuitem" class="nav-link">Byd Copr Cymru</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/cy/busnes/">Busnes</a>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/cy/cyn-fyfyrwyr/">Cyn-fyfyrwyr</a>
</li>

    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Y Brifysgol</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="http://www.swansea.ac.uk/cy/swyddfar-wasg/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Swyddfa'r Wasg</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/press-office-mega-menu-cta.png" alt="Female student working with steel"  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">Newyddion a Ymchwil Diweddaraf straeon</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="http://www.swansea.ac.uk/cy/swyddfar-wasg/">Darllenwch y newyddion diweddaraf yma</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/y-brifysgol/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Y Brifysgol</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/amdanom-ni/" role="menuitem" class="nav-link">Amdanom ni</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/lleoliad/" role="menuitem" class="nav-link">Sut i ddod o hyd i ni</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/gwobrau-ac-anrhydeddau/" role="menuitem" class="nav-link">Dyfarniadau a Safleoedd y Brifysgol  </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/cyfadrannau/" role="menuitem" class="nav-link">Ein Cyfadrannau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.swansea.ac.uk/cy/swyddfar-wasg/" role="menuitem" class="nav-link">Swyddfa'r Wasg</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/swyddi-a-gweithio-yn-abertawe/" role="menuitem" class="nav-link">Swyddi a Gweithio yn Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/cynaliadwyedd/" role="menuitem" class="nav-link">Cynaliadwyedd ym Mhrifysgol Abertawe</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/sustainability/travel/" role="menuitem" class="nav-link">Teithio i’r campws ac oddi yno</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/cysylltu-a-ni/" role="menuitem" class="nav-link">Cysylltu â ni</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Chwaraeon</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/bod-yn-actif/" role="menuitem" class="nav-link">Bod yn Actif</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/cynghreiriau-cymdeithasol/" role="menuitem" class="nav-link">Cynghreiriau Cymdeithasol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/clybiau-chwaraeon/" role="menuitem" class="nav-link">Clybiau Chwaraeon</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/perfformiad-ac-ysgoloriaethau/" role="menuitem" class="nav-link">Perfformiad</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swanseabaysportspark.wales/cy/" role="menuitem" class="nav-link">Cyfleusterau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/nawdd-chwaraeon-/" role="menuitem" class="nav-link">Nawdd</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/tass-ac-ysgoloriaethau/" role="menuitem" class="nav-link">Ysgoloriaethau</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/chwaraeon/newyddion-chwaraeon/" role="menuitem" class="nav-link">Newyddion</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/y-brifysgol/bywyd-y-campws/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Bywyd y campws</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/llety/" role="menuitem" class="nav-link">Llety</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/amdanom-ni/gwasanaethau-arlwyo/" role="menuitem" class="nav-link">Arlwyo</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/sefydliad-diwylliannol/" role="menuitem" class="nav-link">Sefydliad Diwylliannol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/bywyd-y-campws/y-neuadd-fawr/" role="menuitem" class="nav-link">Y Neuadd Fawr</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.taliesinartscentre.co.uk/cy/index.php" role="menuitem" class="nav-link">Taliesin</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/sefydliad-diwylliannol/creu-taliesin/" role="menuitem" class="nav-link">Creu Taliesin</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.egypt.swan.ac.uk/cy/" role="menuitem" class="nav-link"></a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/bywyd-y-campws/ein-tiroedd/" role="menuitem" class="nav-link">Ein Tiroedd</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/ggs/diwylliant-a-chelfyddydau/cerddoriaeth/" role="menuitem" class="nav-link">Cerddoriaeth</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/virtual-tour-stand-alone/?lang=cymraeg" role="menuitem" class="nav-link">Rhithdaith</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/y-brifysgol/cyfadrannau/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Ein Cyfadrannau</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/dyniaethau-a-gwyddoraucymdeithasol/" role="menuitem" class="nav-link">Cyfadran y Dyniaethau a'r Gwyddorau Cymdeithasol</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/gwyddoniaeth-a-pheirianneg/" role="menuitem" class="nav-link">Cyfadran Gwyddoniaeth a Pheirianneg</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/meddygaeth-iechyd-gwyddor-bywyd/" role="menuitem" class="nav-link">Cyfadran Meddygaeth, Iechyd a Gwyddor Bywyd</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/cyfadrannau/y-coleg/" role="menuitem" class="nav-link">Y Coleg</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/cy/y-brifysgol/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Academïau</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/academi-iechyd-a-llesiant/" role="menuitem" class="nav-link">Academi Iechyd a Llesiant</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/y-brifysgol/sefydliad-astudiaethau-uwch-morgan/" role="menuitem" class="nav-link">Sefydliad Astudiaethau Uwch Morgan (SAUM)</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/cyflogadwyedd/" role="menuitem" class="nav-link">Academi Cyflogadwyedd Abertawe (SEA)</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/academi-hywel-teifi/" role="menuitem" class="nav-link">Academi Hywel Teifi</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cy/academi-cynwysoldeb/" role="menuitem" class="nav-link">Academi Cynwysoldeb a Llwyddiant Dysgwyr Abertawe (SAILS)</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/">Newyddion a Digwyddiadau</a>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/cy/gwasanaethau-cymorth-i-fyfyrwyr/">Cefnogaeth a Lles</a>
</li>

</ul>            </div>
        </div>
    </nav>

<!-- END .primary-nav -->

    <form id="mobile-site-search" class="form-inline primary-nav-form" method="GET" role="search" aria-label="chwilotydd y safle symudol" action="/cy/chwilio/">
        <input class="primary-nav-search" type="text" id="mobile-search-input" name="q" placeholder="Chwiliwch Prifysgol Abertawe" aria-label="Chwiliwch" />
        <input name="c" value="www-cy-meta" type="hidden" />
        <input class="primary-nav-search-button btn btn-primary-alt" type="submit" value="Chwiliwch" />
    </form>

    <script>
    SU.injectedScripts.push(function ($) {
        $('#mobile-search-input').autocompletion({
            datasets: {
                organic: {
                collection: 'www-cy-meta',
                profile   : '_default',
                program   : 'https://swansea.funnelback.co.uk/s/suggest.json',
            }
        },
        length: 3
      });
    });
</script>

    <main id="main" tabindex="-1">

    <div id="contentHeader" class="content-header">
        <div class="container">
            <div class="row">
                <div class="col-12 offset-lg-2 col-lg-10 breadCrumb-holder">
                    <div class="desktop-breadcrumb">
                        <ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadCrumb-list">
<li class="first" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/">
            <span itemprop="name">Hafan</span>
        </a>
        <meta itemprop="position" content="1" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/">
            <span itemprop="name">Swyddfa'r Wasg</span>
        </a>
        <meta itemprop="position" content="2" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/">
            <span itemprop="name">Newyddion a Digwyddiadau</span>
        </a>
        <meta itemprop="position" content="3" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/">
            <span itemprop="name">Newyddion</span>
        </a>
        <meta itemprop="position" content="4" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/">
            <span itemprop="name">2022</span>
        </a>
        <meta itemprop="position" content="5" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/">
            <span itemprop="name">Awst</span>
        </a>
        <meta itemprop="position" content="6" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="">
            <span itemprop="name">Model 3D newydd yn datgelu bod megalodon yn pwyso mwy na 61 dunnell ac yn gallu bwyta morfilod danheddog cyfan
</span>
        </a>
        <meta itemprop="position" content="7" />
    </li>
</ol>
                    </div>
                </div>
                <div class="col-12 offset-lg-2 col-lg-10">
                    <h1 class="content-header-heading">Model 3D newydd yn datgelu bod megalodon yn pwyso mwy na 61 dunnell ac yn gallu bwyta morfilod danheddog cyfan
</h1>
                </div>
                <div class="col-12 col-sm-6 d-lg-none mb-3">
                    
<div class="dropdown">
    <a class="mobile-contextual-nav-toggle" href="#" role="button" id="mobile-contextual-nav" data-toggle="dropdown" data-display="static" aria-haspopup="true" aria-expanded="false">
        Tudalennau cysylltiedig    </a>
    <div class="dropdown-menu" aria-labelledby="mobile-contextual-nav">
        <ul class="contextual-nav ml-2 ml-lg-0">
            <li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/">Newyddion a Digwyddiadau</a>
<ul class="multilevel-linkul-0">
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/">Newyddion</a>
<ul class="multilevel-linkul-1">
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/">2022</a>
<ul class="multilevel-linkul-2">
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/11/">Tachwedd</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/10/">Hydref</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/09/">Medi</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/">Awst</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/07/">Gorffennaf</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/06/">Mehefin</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/05/">Mai</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/04/">Ebrill</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/03/">Mawrth</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/02/">Chwefror</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/01/">Ionawr</a></li>

</ul>

</li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2021/">2021</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2020/">2020</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2019/">2019</a></li>
<li><a class="dropdown-item" href="https://www.swansea.ac.uk/cy/swyddfar-wasg/archif-newyddion/">Archif Newyddion</a></li>

</ul>

</li>
<li><a class="dropdown-item" href="https://events.swansea.ac.uk/">Digwyddiadau</a></li>
<li><a class="dropdown-item" href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/safbwyntiau-abertawe/">Safbwyntiau Abertawe</a></li>

</ul>

</li><li><a class="dropdown-item" href="/cy/swyddfar-wasg/">Gwybodaeth i newyddiadurwyr</a></li><li><a class="dropdown-item" href="https://staff.swansea.ac.uk/professional-services/strategic-communications/">Gwybodaeth i Staff</a></li>
        </ul>
    </div>
</div>

                </div>
            </div>
        </div>
    </div>

    
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-10 order-last">
                <div class="row">
            <div class="container">
    <div class="row">
    <div class="news-article-title-and-body-text col-xl-8">

    <figure>
        <div class="news-article-title-and-body-text-image">
            <img src="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/Megalodon---picture-credit-J.-J.-Giraldo_Banner.jpg" width="1460" height="690"  alt="Darlun o'r megalodon "  />
        </div>
        </figure>

    <div class="news-article-title-and-body-text-description"><p>Mae megalodon a ddarganfuwyd yn y 1860au wedi galluogi tîm rhyngwladol o wyddonwyr dan arweiniad Prifysgol Zurich, Prifysgol Abertawe a'r Coleg Milfeddygaeth Brenhinol i greu'r model 3D mwyaf cyflawn hyd yn hyn o fegalodon – y siarc mwyaf sydd wedi byw erioed.</p></div>

    <div class="news-article-title-and-body-text-article-body">
        <p>Mae gan siarcod ysgerbwd cartilagaidd meddal – mae eu hesgyrn yn fwy tebyg i drwyn person na morddwyd – felly, mae'n annhebygol y byddai eu gweddillion yn ffosileiddio, gan olygu mai prin yw’r dystiolaeth heblaw am weddillion deintyddol i astudio'r megalodon darfodedig.</p>
<p>Serch hynny, yn groes i'r disgwyl, gwnaeth cyfran helaeth o asgwrn cefn megalodon ffosileiddio ar ôl i'r creadur farw'n 46 oed yng nghefnforoedd Mïosen Gwlad Belg oddeutu 18 miliwn o flynyddoedd yn ôl.</p>
<p>Dyma esboniad Jack Cooper, prif awdur yr astudiaeth a myfyriwr PhD ym Mhrifysgol Abertawe: “Mae dannedd siarcod yn ffosiliau cyffredin oherwydd eu cyfansoddiad caled, sy'n eu cadw mewn cyflwr da. Fodd bynnag, mae eu hysgerbydau'n llawn cartilag, ac yn anaml y byddan nhw'n ffosileiddio. Felly, mae asgwrn cefn y megalodon o Sefydliad Gwyddorau Naturiol Gwlad Belg yn ffosil heb ei debyg sydd wedi ein galluogi i gynnal yr astudiaeth unigryw hon a chreu'r model 3D.”</p>
<p>Datgelodd canlyniadau'r model 3D o'r megalodon penodol hwn yr wybodaeth ganlynol:</p>
<ul>
<li>Roedd yn 16 metr o hyd.</li>
<li>Roedd yn pwyso mwy na 61 dunnell.</li>
<li>Gallai nofio oddeutu 1.4 metr yr eiliad.</li>
<li>Roedd angen bron 100,000 o galorïau arno bob dydd.</li>
<li>Oddeutu 10,000 litr oedd maint ei stumog.</li>
</ul>
<p>Mae'r canlyniadau hefyd yn awgrymu y gallai'r megalodon deithio'n bell iawn ac y gallai fwyta ysglyfaethau cyfan hyd at wyth metr o hyd – yr un maint â morfilod danheddog modern, sef ysglyfaethwr cefnforol mwyaf ein hoes.</p>
<p>Yn gyntaf, defnyddiodd aelodau'r tîm ymchwil, sy'n cynnwys ymchwilwyr o'r Swistir, y DU, Unol Daleithiau America, Awstralia a De Affrica, sganiau 3D o'r ffosil o Wlad Belg er mwyn ail-lunio'r asgwrn cefn, gan ei chwyddo i faint go iawn. Yna gwnaethant ail-greu penglog megalodon, gan ddefnyddio sgan 3D a oedd eisoes yn bodoli o benglog morgi mawr gwyn, a gafodd ei chwyddo a'i ffitio â sganiau 3D o ddannedd megalodon. Cafodd y benglog ei chysylltu â'r asgwrn cefn, gan roi model sylfaen o benglog megalodon. Defnyddiwyd sgan 3D o gorff cyfan morgi mawr gwyn er mwyn ychwanegu cnawd at ysgerbwd y megalodon, gan greu model 3D llawn o'i gorff cyfan.</p>
<p>“Mae pwysau'n un o briodweddau pwysicaf unrhyw anifail. Yn achos anifeiliaid darfodedig, gallwn ni ddefnyddio dulliau modelu 3D modern er mwyn amcangyfrif màs y corff ac yna ganfod y berthynas rhwng màs a phriodweddau biolegol eraill megis cyflymder a'r defnydd o ynni,” meddai un o'r cyd-awduron, yr Athro John Hutchinson o'r Coleg Milfeddygaeth Brenhinol yn y DU.</p>
<p>Er mwyn bodloni gofynion ynni o'r fath, rhaid bod y megalodon wedi bwyta creaduriaid llawn calorïau fel mamaliaid morol, y mae'n hysbys bod ganddynt gnawd llawn calorïau. Efallai y byddai bwyta morfilod o faint tebyg i forfilod danheddog modern wedi galluogi'r siarc i nofio filoedd o filltiroedd ar draws cefnforoedd heb fwyta eto am ddeufis.</p>
<p>Meddai uwch-awdur yr astudiaeth, Catalina Pimiento, Athro ym Mhrifysgol Zurich ac Uwch-ddarlithydd ym Mhrifysgol Abertawe: “Mae'r canlyniadau hyn yn awgrymu bod y siarc mawr hwn yn ysglyfaethwr trawsforol o'r radd flaenaf. Mae'n debygol y cafodd tranc y siarc mawr eiconig hwn effaith ar gludiant byd-eang maethynnau, gan ryddhau morfilod mawr rhag pwysau ysglyfaethus cryf.”</p>
<p>Gellir defnyddio'r model 3D cyflawn bellach fel sylfaen ar gyfer modelau yn y dyfodol a rhagor o ymchwil wyddonol. Mae'r casgliadau biolegol newydd sy'n deillio o'r astudiaeth hon yn hybu ein gwybodaeth am yr ysglyfaethwr mawr unigryw ac yn helpu i feithrin dealltwriaeth well o gyfraniad ecolegol rhywogaethau ffawna mawr at ecosystemau morol, a chanlyniadau pellgyrhaeddol eu tranc.</p>
    </div>

<div class="news-article-share-story">
    <h3 class="news-article-share-story-heading">Rhannu'r stori</h3>

    <ul class="news-article-share-story-social-links social-links">
        <li class="social-item-facebook">
            <a class="social-link" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.swansea.ac.uk%2Fcy%2Fswyddfar-wasg%2Fnewyddion-a-digwyddiadau%2Fnewyddion%2F2022%2F08%2Fmodel-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" target="_blank">Facebook (ffenestr newydd)</a>
        </li>

        <li class="social-item-twitter">
            <a class="social-link" href="https://twitter.com/intent/tweet?text=Model%203D%20newydd%20yn%20datgelu%20bod%20megalodon%20yn%20pwyso%20mwy%20na%2061%20dunnell%20ac%20yn%20gallu%20bwyta%20morfilod%20danheddog%20cyfan%0A%20https%3A%2F%2Fwww.swansea.ac.uk%2Fcy%2Fswyddfar-wasg%2Fnewyddion-a-digwyddiadau%2Fnewyddion%2F2022%2F08%2Fmodel-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" target="_blank">Twitter (ffenestr newydd)</a>
        </li>

        <li class="social-item-linkedin">
            <a class="social-link" href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.swansea.ac.uk%2Fcy%2Fswyddfar-wasg%2Fnewyddion-a-digwyddiadau%2Fnewyddion%2F2022%2F08%2Fmodel-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" target="_blank">LinkedIn (ffenestr newydd)</a>
        </li>
    </ul>
</div>

</div>

    <div class="col-xl-4">
    <div class="news-article-meta-data">
        <ul>
            <li><i class="fas fa-calendar-alt"></i> Dydd Iau 18 Awst 2022 12:09 GMT+1</li>

            <li class="news-article-meta-data-author-name"><i class="fa fa-portrait"></i> Catrin Newman</li>

            <li><i class="fa fa-building"></i> Swyddfa&#039;r Wasg</li>

            <li><a href="mailto:c.a.newman@abertawe.ac.uk"><i class="far fa-envelope"></i> c.a.newman@abertawe.ac.uk</a></li>

            <li><i class="fas fa-phone fa-flip-horizontal"></i> 01792 513454</li>
        </ul>

        <div class="d-none d-xl-block">
<div class="news-article-share-story">
    <h3 class="news-article-share-story-heading">Rhannu'r stori</h3>

    <ul class="news-article-share-story-social-links social-links">
        <li class="social-item-facebook">
            <a class="social-link" href="https://www.facebook.com/sharer/sharer.php?u=https%3A%2F%2Fwww.swansea.ac.uk%2Fcy%2Fswyddfar-wasg%2Fnewyddion-a-digwyddiadau%2Fnewyddion%2F2022%2F08%2Fmodel-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" target="_blank">Facebook (ffenestr newydd)</a>
        </li>

        <li class="social-item-twitter">
            <a class="social-link" href="https://twitter.com/intent/tweet?text=Model%203D%20newydd%20yn%20datgelu%20bod%20megalodon%20yn%20pwyso%20mwy%20na%2061%20dunnell%20ac%20yn%20gallu%20bwyta%20morfilod%20danheddog%20cyfan%0A%20https%3A%2F%2Fwww.swansea.ac.uk%2Fcy%2Fswyddfar-wasg%2Fnewyddion-a-digwyddiadau%2Fnewyddion%2F2022%2F08%2Fmodel-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" target="_blank">Twitter (ffenestr newydd)</a>
        </li>

        <li class="social-item-linkedin">
            <a class="social-link" href="https://www.linkedin.com/sharing/share-offsite/?url=https%3A%2F%2Fwww.swansea.ac.uk%2Fcy%2Fswyddfar-wasg%2Fnewyddion-a-digwyddiadau%2Fnewyddion%2F2022%2F08%2Fmodel-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php" target="_blank">LinkedIn (ffenestr newydd)</a>
        </li>
    </ul>
</div>
        </div>

    </div>
</div>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "NewsArticle",
  "mainEntityOfPage": {
    "@type": "WebPage",
    "@id": "https://www.swansea.ac.uk/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/model-3d-newydd-yn-datgelu-bod-megalodon-yn-pwyso-mwy-na-61-dunnell-ac-yn-gallu-bwyta-morfilod-danheddog-cyfan.php"
  },
  "headline": "Model 3D newydd yn datgelu bod megalodon yn pwyso mwy na 61 dunnell ac yn gallu bwyta morfilod danheddog cyfan
",
  "image": [
    "https://www.swansea.ac.uk/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/Megalodon---picture-credit-J.-J.-Giraldo_Banner.jpg",
    "https://www.swansea.ac.uk/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/Megalodon---picture-credit-J.-J.-Giraldo_Thumb.jpg"
   ],
  "datePublished": "2022-08-18T12:09:00+0100",
  "dateModified": "2022-08-17T11:58:32+0100",
  "author": {
    "@type": "Person",
    "name": "Catrin Newman"
  },
   "publisher": {
    "@type": "Organization",
    "name": "Prifysgol Abertawe",
    "logo": {
      "@type": "ImageObject",
      "url": "https://www.swansea.ac.uk/_assets/images/logos/swansea-university-2017.cy.png",
      "height": "385",
      "width": "693"
    }
  }
}
</script>


    </div>
</div>
                    </div>
            </div>
            <div class="d-none d-lg-block col-md-2 order-first">
                <nav aria-label="Tudalennau cysylltiedig">
                    <ul class="contextual-nav">
    <li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/">Newyddion a Digwyddiadau</a>
<ul class="multilevel-linkul-0">
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/">Newyddion</a>
<ul class="multilevel-linkul-1">
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/">2022</a>
<ul class="multilevel-linkul-2">
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/11/">Tachwedd</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/10/">Hydref</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/09/">Medi</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/08/">Awst</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/07/">Gorffennaf</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/06/">Mehefin</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/05/">Mai</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/04/">Ebrill</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/03/">Mawrth</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/02/">Chwefror</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2022/01/">Ionawr</a></li>

</ul>

</li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2021/">2021</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2020/">2020</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/newyddion/2019/">2019</a></li>
<li><a href="https://www.swansea.ac.uk/cy/swyddfar-wasg/archif-newyddion/">Archif Newyddion</a></li>

</ul>

</li>
<li><a href="https://events.swansea.ac.uk/">Digwyddiadau</a></li>
<li><a href="/cy/swyddfar-wasg/newyddion-a-digwyddiadau/safbwyntiau-abertawe/">Safbwyntiau Abertawe</a></li>

</ul>

</li><li><a href="/cy/swyddfar-wasg/">Gwybodaeth i newyddiadurwyr</a></li><li><a href="https://staff.swansea.ac.uk/professional-services/strategic-communications/">Gwybodaeth i Staff</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    </main>


    <footer>
        <div class="container">
            <div class="row">
                <div class="footer-links-info">
                    <ul class="footer-links-list">
<li class="footer-links-list-item"><a href="/cy/cysylltu-a-ni/">Cysylltwch &acirc; ni</a></li><li class="footer-links-list-item"><a href="https://swansea.ac.uk/cy/personel/swyddi/">Swyddi</a></li><li class="footer-links-list-item"><a href="https://swansea.ac.uk/cy/y-brifysgol/colegau/">Cyfadrannau</a></li><li class="footer-links-list-item"><a href="https://swansea.ac.uk/cy/canolfan-y-cyfryngau/">Y Wasg</a></li><li class="footer-links-list-item"><a href="https://www.swansea.ac.uk/about-us/safety-and-security/health-and-safety/">Iechyd a Diogelwch</a></li><li class="footer-links-list-item"><a href="/cy/system/footer/ymwadiad-a-hawlfraint/">Ymwadiad a Hawlfraint</a></li><li class="footer-links-list-item"><a href="https://www.swansea.ac.uk/cy/cynnwys/footer/map-o'r-safle/">Map o'r Safle</a></li><li class="footer-links-list-item"><a href="/cy/preifatrwydd-a-chwcis/">Preifatrwydd a Chwcis</a></li><li class="footer-links-list-item"><a href="https://www.swansea.ac.uk/media/Deddf-Caethwasiaeth-Fodern.pdf">Datganiad Caethwasiaeth Fodern</a></li>
                    </ul>
                    <ul class="footer-info-list">
                        <li class="footer-info-list-item">Mae Prifysgol Abertawe yn elusen gofrestredig, Rhif 1138342</li>
                    </ul>
                </div>
    <div class="footer-social">
    <ul class="footer-social-list">

        <li class="footer-social-list-item">
            <a href="https://www.facebook.com/prifysgol.abertawe" aria-label="Prifysgol Abertawe ar Facebook">
                <i class="fab fa-facebook-square"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.instagram.com/prifabertawe/" aria-label="Prifysgol Abertawe ar Instagram">
                <i class="fab fa-instagram"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://twitter.com/Prif_Abertawe" aria-label="Prifysgol Abertawe ar Twitter">
                <i class="fab fa-twitter"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.tiktok.com/@swanseauni" aria-label="Prifysgol Abertawe ar TikTok">
                <i class="fab fa-tiktok"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.youtube.com/user/PrifAbertawe" aria-label="Prifysgol Abertawe ar YouTube">
                <i class="fab fa-youtube"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.flickr.com/photos/swanseauniversity/" aria-label="Prifysgol Abertawe ar Flickr">
                <i class="fab fa-flickr"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.linkedin.com/school/swansea-university/" aria-label="Prifysgol Abertawe ar LinkedIn">
                <i class="fab fa-linkedin"></i>
            </a>
        </li>


    </ul>
</div>

            </div>
        </div>
    </footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
<script src="https://ik.imagekit.io/s1sp3stox/_web/js/www-bundle.min.js?v=b348f1a3104466ceba9ead35abeb8974&ik-sdk-version=php-2.0.0"></script>

</body>
</html>
