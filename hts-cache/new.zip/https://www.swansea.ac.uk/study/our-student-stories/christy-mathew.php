<!DOCTYPE html>
<html class="no-js" lang="en-GB" prefix="og: http://ogp.me/ns#">
<head>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-2764516-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-2764516-1');
  gtag('config', 'UA-2764516-41');
</script>
            <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/fonts/futura/hinted-FuturaPTBold-Reg.woff2?ik-sdk-version=php-2.0.0" as="font" type="font/woff2" crossorigin>
    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/fonts/futura/hinted-FuturaPTBook-Reg.woff2?ik-sdk-version=php-2.0.0" as="font" type="font/woff2" crossorigin>

    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/js/www-bundle.min.js?v=b348f1a3104466ceba9ead35abeb8974&ik-sdk-version=php-2.0.0" as="script">

    <link rel="preload" href="https://ik.imagekit.io/s1sp3stox/_web/css/general.min.css?v=cadd65eee68e59e01d07512b07c275b2&ik-sdk-version=php-2.0.0" as="style">
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <meta property="su:section-id" content="86618" />
    






        <title>Christy Mathew - Swansea University</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="apple-touch-icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/icons/apple-touch-icon.png?ik-sdk-version=php-2.0.0">
        <link rel="icon" type="image/png" sizes="32x32" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon-32x32.png?ik-sdk-version=php-2.0.0">
    <link rel="icon" type="image/png" sizes="16x16" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon-16x16.png?ik-sdk-version=php-2.0.0">
    <link rel="manifest" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/site.webmanifest?ik-sdk-version=php-2.0.0">
    <link rel="mask-icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/safari-pinned-tab.svg?ik-sdk-version=php-2.0.0" color="#5bbad5">
    <link rel="shortcut icon" href="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/favicon.ico?ik-sdk-version=php-2.0.0">
    <meta name="msapplication-TileColor" content="#da532c">
    <meta name="msapplication-config" content="https://ik.imagekit.io/s1sp3stox/_web/img/favicon/www/browserconfig.xml?ik-sdk-version=php-2.0.0">
    <meta name="theme-color" content="#ffffff">

        <link rel="stylesheet" href="https://ik.imagekit.io/s1sp3stox/_web/css/general.min.css?v=cadd65eee68e59e01d07512b07c275b2&ik-sdk-version=php-2.0.0" type="text/css" media="all" />

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        function isAtLeastPartiallyVisible(el) {
            const rect = el.getBoundingClientRect();
            return rect.top < window.innerHeight && rect.bottom >= 0;
        }

        document.querySelectorAll('img').forEach(function(img) {
            if (isAtLeastPartiallyVisible(img)) {
                img.removeAttribute('loading');
            } else {
                img.setAttribute('loading', 'lazy');
            }
        });
    }, false);
</script>

    <script src="https://kit.fontawesome.com/026410dcd9.js" crossorigin="anonymous"></script>

        <link rel="canonical" href="https://www.swansea.ac.uk/study/our-student-stories/christy-mathew.php" />

    <script>
      (function(d) {
        var config = {
          kitId: 'lnz6iij',
          scriptTimeout: 3000,
          async: true
        },
        h=d.documentElement,t=setTimeout(function(){h.className=h.className.replace(/\bwf-loading\b/g,"")+" wf-inactive";},config.scriptTimeout),tk=d.createElement("script"),f=false,s=d.getElementsByTagName("script")[0],a;h.className+=" wf-loading";tk.src='https://use.typekit.net/'+config.kitId+'.js';tk.async=true;tk.onload=tk.onreadystatechange=function(){a=this.readyState;if(f||a&&a!="complete"&&a!="loaded")return;f=true;clearTimeout(t);try{Typekit.load(config)}catch(e){}};s.parentNode.insertBefore(tk,s)
      })(document);
    </script>

    <script>
        var SU = {
            injectedScripts: []
        };
    </script>



<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-5MZHZM');</script></head>

<body>

<noscript><iframe title="Google Tag Manager" src="//www.googletagmanager.com/ns.html?id=GTM-5MZHZM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>

<script data-cookieconsent="ignore">
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag("consent", "default", {
        ad_storage: "denied",
        analytics_storage: "denied",
        wait_for_update: 500
    });
    gtag("set", "ads_data_redaction", true);
</script>

    <header id="banner">
        <div class="container">
            <a class="skip-to-main" href="#main">Skip to main content</a>

    
<a href="/" class="logo logo-www">
    <picture>
        <source type="image/svg+xml" srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.svg?ik-sdk-version=php-2.0.0" />
        <img
            src="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0"
            srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0, https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en@2x.png?ik-sdk-version=php-2.0.0 2x"
            alt="Swansea University"
            width="185"
            height="116"
        />
    </picture>
</a>

    <form method="GET" role="search" aria-label="site search" action="/search/">
        <label for="keywords">Search:</label>
        <input type="text" id="keywords" name="q" placeholder="Search Swansea University" />
        <input name="c" value="www-en-meta" type="hidden" />
        <button id="search-button" aria-label="site search button" type="submit" tabindex="0">Search</button>
    </form>

    <script>
    SU.injectedScripts.push(function ($) {
        $('#keywords').autocompletion({
            datasets: {
                organic: {
                collection: 'www-en-meta',
                profile   : '_default',
                program   : 'https://swansea.funnelback.co.uk/s/suggest.json',
            }
        },
        length: 3
      });
    });
</script>
        
    <ul class="utility-links">

    <li>
        <a href="/jobs-at-swansea/" title="Jobs at Swansea University">Jobs</a>
    </li>

    <li>
        <a class="utility-links-recite-me-link" href="#" onclick="return false;" title="Accessibility Tools">Accessibility Tools</a>
    </li>

    <li>
        <a href="https://myuni.swansea.ac.uk/">Current Students</a>
    </li>

    <li>
        <a href="https://staff.swansea.ac.uk/">Staff</a>
    </li>

    <li>
        <a href="http://www.swanseauniversity.com.cn/" aria-label="A link to information in Chinese about Swansea University">中文</a>
    </li>

    <li>
        <a href="/cy/astudio/ein-storiau-myfyrwyr/christy-mathew.php" lang="cy-GB">Cymraeg</a>
    </li>

</ul>

        </div>
    </header>


    <nav class="navbar navbar-expand-lg primary-nav  yamm ">
        <div class="container">
            <button class="navbar-toggler" data-toggle="collapse" data-target="#primary-nav-content">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30" width="30" height="30" focusable="false"><title>Menu</title><path stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-miterlimit="10" d="M4 7h22M4 15h22M4 23h22"></path></svg>
            </button>
    
<a href="/" class="logo logo-www">
    <picture>
        <source type="image/svg+xml" srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.svg?ik-sdk-version=php-2.0.0" />
        <img
            src="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0"
            srcset="https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en.png?ik-sdk-version=php-2.0.0, https://ik.imagekit.io/s1sp3stox/_web/img/logo/stacked/logo-white-stacked-en@2x.png?ik-sdk-version=php-2.0.0 2x"
            alt="Swansea University"
            width="185"
            height="116"
        />
    </picture>
</a>

            <button id="mobile-site-search-button" class="primary-nav-search-anchor" type="button" aria-label="show mobile site search" aria-expanded="false" aria-controls="mobile-site-search"></button>
        </div>

        <div class="container-lg primary-nav-toggler-content-container">   
            <div class="collapse navbar-collapse primary-nav-toggler-content" id="primary-nav-content">
                <!-- START .primary-nav-utility holds lang and contextual -->
                <div class="primary-nav-utility">
    <ul class="primary-nav-utility-links">

    <li>
        <a href="/jobs-at-swansea/" title="Jobs at Swansea University">Jobs</a>
    </li>

    <li>
        <a class="utility-links-recite-me-link" href="#" onclick="return false;" title="Accessibility Tools">Accessibility Tools</a>
    </li>

    <li>
        <a href="https://myuni.swansea.ac.uk/">Current Students</a>
    </li>

    <li>
        <a href="https://staff.swansea.ac.uk/">Staff</a>
    </li>

    <li>
        <a href="http://www.swanseauniversity.com.cn/" aria-label="A link to information in Chinese about Swansea University">中文</a>
    </li>

    <li>
        <a href="/cy/astudio/ein-storiau-myfyrwyr/christy-mathew.php" lang="cy-GB">Cymraeg</a>
    </li>

</ul>
    <div class="primary-nav-breadCrumb d-md-none">
        <ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadCrumb-list">
<li class="first" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/">
            <span itemprop="name">Home</span>
        </a>
        <meta itemprop="position" content="1" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/the-university/">
            <span itemprop="name">The University</span>
        </a>
        <meta itemprop="position" content="2" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/study/">
            <span itemprop="name">Study</span>
        </a>
        <meta itemprop="position" content="3" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/study/our-student-stories/">
            <span itemprop="name">Student Stories</span>
        </a>
        <meta itemprop="position" content="4" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="">
            <span itemprop="name">Christy Mathew</span>
        </a>
        <meta itemprop="position" content="5" />
    </li>
</ol>
    </div>
                </div>
                <!-- END .primary-nav-utility -->
    <ul class="navbar-nav" role="menu">
    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Study</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/our-open-days/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Open Days at Swansea</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/swansea-university-students-on-bay-campus.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/swansea-university-students-on-bay-campus.jpg" alt="Three students walking through Bay Campus in the Sun"  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">We can&#039;t wait to meet you!</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/our-open-days/">Visit us</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/undergraduate/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Undergraduate</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/undergraduate/courses/" role="menuitem" class="nav-link">Courses</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/accommodation/" role="menuitem" class="nav-link">Accommodation</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/clearing/" role="menuitem" class="nav-link">Clearing at Swansea</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/parents/" role="menuitem" class="nav-link">Parents and Guardians Guide to University</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/open-days/" role="menuitem" class="nav-link">Open Days</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/undergraduate/how-to-apply/" role="menuitem" class="nav-link">How to Apply</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/undergraduate/scholarships/" role="menuitem" class="nav-link">Scholarships and Bursaries</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/undergraduate/contact-admissions/" role="menuitem" class="nav-link">Make an Undergrad Enquiry</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/keep-in-touch/" role="menuitem" class="nav-link">Keep in Touch</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/postgraduate/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Postgraduate</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/taught/" role="menuitem" class="nav-link">Taught Courses</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/research/" role="menuitem" class="nav-link">Research Programmes</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/open-days/" role="menuitem" class="nav-link">Open Days</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/apply/" role="menuitem" class="nav-link">How to Apply</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/scholarships/" role="menuitem" class="nav-link">Scholarships and Bursaries</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-university/" role="menuitem" class="nav-link">Your University</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/contact-admissions/" role="menuitem" class="nav-link">Make a Postgrad Enquiry</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/keep-in-touch/" role="menuitem" class="nav-link">Keep in Touch</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/international-students/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">International Students</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/international-student-courses/" role="menuitem" class="nav-link">Courses</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/international-student-courses/how-to-apply/" role="menuitem" class="nav-link">How to Apply</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/my-finances/international-scholarships/" role="menuitem" class="nav-link">Scholarships and Bursaries</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-students/my-country/" role="menuitem" class="nav-link">Your Country Information</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international-campuslife/" role="menuitem" class="nav-link">Support for International Students</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/goglobal/" role="menuitem" class="nav-link">Study Abroad &amp; Exchange</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/english-language-training-services/" role="menuitem" class="nav-link">English Language Training Services</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-college/" role="menuitem" class="nav-link">International Pathways</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/international/contact-us/" role="menuitem" class="nav-link">Ask Us a Question</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/study/student-life/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Student Life</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/" role="menuitem" class="nav-link">Study</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/why-study-in-swansea/" role="menuitem" class="nav-link">Why Swansea</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/our-student-stories/" role="menuitem" class="nav-link">Our Student Stories</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/life-on-campus/" role="menuitem" class="nav-link">Life on Campus</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/" role="menuitem" class="nav-link">Sport</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sustainability/get-involved/" role="menuitem" class="nav-link">Sustainability - Get Involved</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cultural-institute/" role="menuitem" class="nav-link">Arts and Culture</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/student-life/susu/" role="menuitem" class="nav-link">Swansea University Students' Union</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/virtual-tour-stand-alone/" role="menuitem" class="nav-link">Virtual tours</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/study/freshers/" role="menuitem" class="nav-link">What is Freshers?</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/student-services/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Student Services</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/library/" role="menuitem" class="nav-link">Library</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/campuslife/" role="menuitem" class="nav-link">CampusLife</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sea/" role="menuitem" class="nav-link">Swansea Employability Academy (SEA)</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://myuni.swansea.ac.uk/employability-enterprise/student-enterprise/" role="menuitem" class="nav-link">Student Enterprise</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/academic-success/" role="menuitem" class="nav-link">Centre for Academic Success</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/academi-hywel-teifi/" role="menuitem" class="nav-link">Welsh on Campus</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/student-support-services/" role="menuitem" class="nav-link">Student Wellbeing</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/international/">International </a>
</li>

    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Our Research</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/research/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Our Research</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/kaleidoscope-image-no-words.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/kaleidoscope-image-no-words.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/kaleidoscope-image-no-words.jpg?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/kaleidoscope-image-no-words.jpg" alt=""  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">Find out more about our world-changing research</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/research/">Read more</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/research-with-us/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Research with us</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-with-us/postgraduate-research/" role="menuitem" class="nav-link">Supporting your postgraduate research journey</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/research/" role="menuitem" class="nav-link">Find a postgraduate research programme</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/postgraduate/research/apply/" role="menuitem" class="nav-link">How to apply for your Postgraduate Research programme</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-with-us/postgraduate-research/training-and-skills-development-programme/" role="menuitem" class="nav-link">Training and Development for Research Students and Supervisors</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/explore-our-research/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Explore our research</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-highlights/" role="menuitem" class="nav-link">Research Highlights</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/explore-our-research/research-in-the-faculties/" role="menuitem" class="nav-link">Research in the faculties</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/momentum-magazine/" role="menuitem" class="nav-link">Momentum Magazine</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/podcasts/" role="menuitem" class="nav-link">Global Challenges Podcast Series</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/discover-our-expertise/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Discover our expertise</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/discover-our-expertise/" role="menuitem" class="nav-link">Find a Researcher</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://cronfa.swan.ac.uk/" role="menuitem" class="nav-link">Find a research publication</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/business-and-industry/access-our-research-development/" role="menuitem" class="nav-link">Access our Research Expertise</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/research-environment/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Research Environment</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-integrity-ethics-governance/" role="menuitem" class="nav-link">Research Integrity: Ethics and Governance</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-impact/" role="menuitem" class="nav-link">Research Impact</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/research/research-environment/research-staff-development/" role="menuitem" class="nav-link">Training and Development</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/masi/" role="menuitem" class="nav-link">Morgan Advanced Studies Institute (MASI) </a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/research/civic-mission/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Our Civic Mission</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/swansea-science-festival/" role="menuitem" class="nav-link">Swansea Science Festival</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://beinghumanfestival.org/" role="menuitem" class="nav-link">Being Human Festival</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://orielscience.co.uk/" role="menuitem" class="nav-link">Oriel Science</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.welshcopper.org.uk/en/index.htm" role="menuitem" class="nav-link">A World of Welsh Copper</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/business-and-industry/">Business</a>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/alumni/">Alumni</a>
</li>

    <li class="nav-item dropdown yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link dropdown-toggle" role="menuitem" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Your University</a>
    <div class="dropdown-menu">
        <ul class="row yamm-content primary-nav-panel-content" role="menu">

            <li class="nav-item col-lg-2" role="none">
                <a href="/press-office/" role="menuitem">
                    <span class="primary-nav-panel-content-submenu-header">Press Office</span>
                    <div class="primary-nav-panel-content-image">
                        <picture>
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-127,w-198,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 1200px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-90,w-141,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 992px)">
    <source srcset="https://ik.imagekit.io/s1sp3stox/tr:h-45,w-70,fo-auto/media/press-office-mega-menu-cta.png?ik-sdk-version=php-2.0.0" media="(min-width: 320px)">
    <img src="/media/press-office-mega-menu-cta.png" alt="Female student working with steel"  loading="lazy">
</picture>
                    </div>
                </a>
                <p class="primary-nav-panel-content-caption mt-2">Latest news and research</p>
                <a class="primary-nav-panel-content-button primary-nav-button" role="menuitem" href="/press-office/">Press Office</a>
            </li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/the-university/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Your University</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/about-us/" role="menuitem" class="nav-link">About us</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-university/location/" role="menuitem" class="nav-link">How to Find Us</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/awards/" role="menuitem" class="nav-link">University Awards and Rankings</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-university/faculties/" role="menuitem" class="nav-link">Our Faculties</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/press-office/" role="menuitem" class="nav-link">Press Office</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/jobs-at-swansea/" role="menuitem" class="nav-link">Job Opportunities and Working At Swansea</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sustainability/" role="menuitem" class="nav-link">Sustainability at Swansea University</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/travel/" role="menuitem" class="nav-link">Travel to and from Campus</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/contact-us/" role="menuitem" class="nav-link">Contact Us</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/sport/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Sport</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/get-active/" role="menuitem" class="nav-link">Get ACTIVE</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/social-leagues/" role="menuitem" class="nav-link">Social Leagues</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/clubs/" role="menuitem" class="nav-link">Club Sport</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/high-performance/" role="menuitem" class="nav-link">Performance</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swanseabaysportspark.wales/" role="menuitem" class="nav-link">Facilities</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/sponsor-us/" role="menuitem" class="nav-link">Sponsorship</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/scholarships-and-tass/" role="menuitem" class="nav-link">Scholarships</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sport/news-and-updates/" role="menuitem" class="nav-link">News</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/life-on-campus/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Life on Campus</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/accommodation/" role="menuitem" class="nav-link">Accommodation</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/catering/" role="menuitem" class="nav-link">Catering</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cultural-institute/" role="menuitem" class="nav-link">Arts and Culture</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/life-on-campus/the-great-hall/" role="menuitem" class="nav-link">The Great Hall</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.taliesinartscentre.co.uk/en/" role="menuitem" class="nav-link">Taliesin</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/cultural-institute/taliesin-create/" role="menuitem" class="nav-link">Taliesin Create</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="http://www.egypt.swan.ac.uk/" role="menuitem" class="nav-link">Egypt Centre</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/life-on-campus/our-grounds/" role="menuitem" class="nav-link">Our Grounds</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/music/" role="menuitem" class="nav-link">Musical Opportunities</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="https://www.swansea.ac.uk/virtual-tour-stand-alone/" role="menuitem" class="nav-link">Virtual Tour</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/the-university/faculties/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Our Faculties</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/humanities-and-socialsciences/" role="menuitem" class="nav-link">Faculty of Humanities and Social Sciences</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/medicine-health-life-science/" role="menuitem" class="nav-link">Faculty of Medicine, Health and Life Science </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/science-and-engineering/" role="menuitem" class="nav-link">Faculty of Science and Engineering</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/the-college/" role="menuitem" class="nav-link">The College</a>
</li>


        </ul>
    
</li>

    <li class="nav-item col-lg-2" role="none">
    <a href="/the-university/" role="menuitem" class="primary-nav-panel-content-submenu-header nav-link" aria-haspopup="true" aria-expanded="false">Academies</a>


        <ul>
    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/hwa/" role="menuitem" class="nav-link">Health and Wellbeing Academy </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/masi/" role="menuitem" class="nav-link">Morgan Advanced Studies Institute (MASI) </a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/sea/" role="menuitem" class="nav-link">Swansea Employability Academy (SEA)</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/academi-hywel-teifi/" role="menuitem" class="nav-link">Academi Hywel Teifi</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/inclusivity-academy/" role="menuitem" class="nav-link">Swansea Academy of Inclusivity</a>
</li>


    

    
    <li class="nav-item primary-nav-panel-content-submenu-link" role="none">
    <a href="/iss/salt/" role="menuitem" class="nav-link">SALT</a>
</li>


        </ul>
    
</li>

        </ul>
    </div>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/press-office/news-events/">News and Events</a>
</li>

    <li class="nav-item yamm-fw mr-1 mr-xl-3" role="none">
    <a class="nav-link" role="menuitem" href="/student-support-services/">Support &amp; Wellbeing</a>
</li>

</ul>            </div>
        </div>
    </nav>

<!-- END .primary-nav -->

    <form id="mobile-site-search" class="form-inline primary-nav-form" method="GET" role="search" aria-label="mobile site search" action="/search/">
        <input class="primary-nav-search" type="text" id="mobile-search-input" name="q" placeholder="Search Swansea University" aria-label="Search" />
        <input name="c" value="www-en-meta" type="hidden" />
        <input class="primary-nav-search-button btn btn-primary-alt" type="submit" value="Search" />
    </form>

    <script>
    SU.injectedScripts.push(function ($) {
        $('#mobile-search-input').autocompletion({
            datasets: {
                organic: {
                collection: 'www-en-meta',
                profile   : '_default',
                program   : 'https://swansea.funnelback.co.uk/s/suggest.json',
            }
        },
        length: 3
      });
    });
</script>

    <main id="main" tabindex="-1">

    <div id="contentHeader" class="content-header">
        <div class="container">
            <div class="row">
                <div class="col-12 offset-lg-2 col-lg-10 breadCrumb-holder">
                    <div class="desktop-breadcrumb">
                        <ol itemscope itemtype="http://schema.org/BreadcrumbList" class="breadCrumb-list">
<li class="first" itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/">
            <span itemprop="name">Home</span>
        </a>
        <meta itemprop="position" content="1" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/the-university/">
            <span itemprop="name">The University</span>
        </a>
        <meta itemprop="position" content="2" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/study/">
            <span itemprop="name">Study</span>
        </a>
        <meta itemprop="position" content="3" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="/study/our-student-stories/">
            <span itemprop="name">Student Stories</span>
        </a>
        <meta itemprop="position" content="4" />
    </li>
<li  itemprop="itemListElement" itemscope itemtype="http://schema.org/ListItem">
        <a itemprop="item" href="">
            <span itemprop="name">Christy Mathew</span>
        </a>
        <meta itemprop="position" content="5" />
    </li>
</ol>
                    </div>
                </div>
                <div class="col-12 col-sm-6 d-lg-none mb-3">
                                    </div>
            </div>
        </div>
    </div>

    
    <div class="container">
        <div class="row">
            <div class="col-sm-12 col-lg-10 order-last">
                <div class="row">
            <div class="container">
    <div class="row">
    <div class="col-12">
    <div class="student-story-overview">


        <div class="student-story-overview-profile-image">
            <img
    src="/study/our-student-stories/Christy-Mathew-7---small.jpg"
    alt="Christy Mathew"
    srcset="
        https://ik.imagekit.io/s1sp3stox/tr:h-400,w-400,fo-none/study/our-student-stories/Christy-Mathew-7---small.jpg?ik-sdk-version=php-2.0.0 400w,
        https://ik.imagekit.io/s1sp3stox/tr:h-200,w-200,fo-none/study/our-student-stories/Christy-Mathew-7---small.jpg?ik-sdk-version=php-2.0.0 200w,
        https://ik.imagekit.io/s1sp3stox/tr:h-150,w-150,fo-none/study/our-student-stories/Christy-Mathew-7---small.jpg?ik-sdk-version=php-2.0.0 150w
    "
    sizes="
        (min-width: 1200px) 200px,
        (min-width: 992px) 150px,
        100px
    "
>
        </div>

        <h1>Christy Mathew</h1>

        <dl class="row">
            <dt class="col-1">Country:</dt>
            <dd class="col">India</dd>
            <div class="w-100"></div>
            <dt class="col-1">Course:</dt>
            <dd class="col">MSc Public Health and Health Promotion</dd>
        </dl>

        <div class="student-story-overview-introduction"></div>
    </div>
</div>

    <div class="col-md-8">
    <p>
    <strong>Why did you choose to study at Swansea University? </strong>
</p>
<p>
    I chose Swansea University because it is highly acclaimed in Medicine & Health. My course is unique in itself because unlike other Public Health courses, it teaches about health promotion: a
    practical approach which can be a great start for my career! Finally, this course ensures governmental accreditation for students who pass the course successfully.
</p>
<p>
    <strong>Can you tell us about your course and what do you enjoy the most?</strong>
</p>
<p>
    I was very excited to understand this particular field of health, so getting to interact with my professors, who are highly experienced and share their wealth of knowledge with us is a part of my
    dream. I’m living my dream. I love the lectures and the anecdotes they share. The assignments are hard work but very rewarding in broadening my understanding about the subject. 
</p>
<p>
    <strong>What are your three favourite things about Swansea?</strong>
</p>
<p>
    I love the University campus, it is exactly what I expected! I love the ‘Wednesdays-student’ nightlife! All my new friends and ALL my classmates (so helpful & social), they make Swansea a
    beautiful place for me! Last but not the least, I can’t help but mention the scenic beauty of the Welsh land which is eye-catchy and rejuvenating.
</p>
<p>
    <strong>Would you recommend Swansea University to other international students?</strong>
</p>
<p>
    Definitely! No two answers to that. There are multiple opportunities for international students whether it is funding related or career placement-wise. Many more deserving students should take
    advantage of this privilege.
</p>

</div>

    <div class="col-12 col-md-6">
    <h2>Find out more</h2>

    <ul>
        <li>
            <a href="/postgraduate/taught/health-social-care/public-health-and-health-promotion-msc-pgdip/">Public Health and Health Promotion, MSc/PGDip</a>
        </li>
        <li>
            <a href="/health-social-care/">School of Health and Social Care</a>
        </li>
        <li>
            <a href="/medicine-health-life-science/">Faculty of Medicine, Health and Life Science </a>
        </li>
    </ul>
</div>

    </div>
</div>
                    </div>
            </div>
            <div class="d-none d-lg-block col-md-2 order-first">
                <nav aria-label="Related pages">
                    <ul class="contextual-nav">
    
                    </ul>
                </nav>
            </div>
        </div>
    </div>

    </main>


    <footer>
        <div class="container">
            <div class="row">
                <div class="footer-links-info">
                    <ul class="footer-links-list">
<li class="footer-links-list-item"><a href="/contact-us/">Contact Us</a></li><li class="footer-links-list-item"><a href="/jobs-at-swansea/">Jobs</a></li><li class="footer-links-list-item"><a href="/the-university/faculties/">Faculties</a></li><li class="footer-links-list-item"><a href="/press-office/">Press</a></li><li class="footer-links-list-item"><a href="/about-us/safety-and-security/health-and-safety/">Health &amp; Safety</a></li><li class="footer-links-list-item"><a href="/disclaimer-and-copyright/">Disclaimer &amp; Copyright</a></li><li class="footer-links-list-item"><a href="/system/site-map/">Site Map</a></li><li class="footer-links-list-item"><a href="/privacyandcookies/">Privacy &amp; Cookies</a></li><li class="footer-links-list-item"><a href="/media/Modern-Slavery-Statement.pdf">Modern Slavery Statement</a></li><li class="footer-links-list-item"><a href="/the-university/accessibility/swansea-ac-uk/">Accessibility Statement</a></li>
                    </ul>
                    <ul class="footer-info-list">
                        <li class="footer-info-list-item">Swansea University is a registered charity, No. 1138342</li>
                    </ul>
                </div>
    <div class="footer-social">
    <ul class="footer-social-list">

        <li class="footer-social-list-item">
            <a href="https://www.facebook.com/swanseauniversity" aria-label="Swansea University on Facebook">
                <i class="fab fa-facebook-square"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.instagram.com/swanseauni/?hl=en" aria-label="Swansea University on Instagram">
                <i class="fab fa-instagram"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://twitter.com/SwanseaUni" aria-label="Swansea University on Twitter">
                <i class="fab fa-twitter"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.tiktok.com/@swanseauni" aria-label="Swansea University on TikTok">
                <i class="fab fa-tiktok"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.youtube.com/user/SwanseaUniVideo" aria-label="Swansea University on YouTube">
                <i class="fab fa-youtube"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.flickr.com/photos/swanseauniversity/" aria-label="Swansea University on Flickr">
                <i class="fab fa-flickr"></i>
            </a>
        </li>

        <li class="footer-social-list-item">
            <a href="https://www.linkedin.com/school/swansea-university/" aria-label="Swansea University on LinkedIn">
                <i class="fab fa-linkedin"></i>
            </a>
        </li>


    </ul>
</div>

            </div>
        </div>
    </footer>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>
<script src="https://ik.imagekit.io/s1sp3stox/_web/js/www-bundle.min.js?v=b348f1a3104466ceba9ead35abeb8974&ik-sdk-version=php-2.0.0"></script>

</body>
</html>
